function h = waitbar(varargin)
% WAITBAR override -- disables the graphical progress bar entirely.
%
% WHY THIS EXISTS: genfis's subtractive clustering internally calls the
% real waitbar() to show a progress dialog. On headless/remote/cloud
% MATLAB sessions (like this one), creating that graphical dialog can
% trigger a "Graphics timeout" stall -- since genfis gets called
% repeatedly inside a PSO/GA/GWO search loop, this can look exactly
% like a frozen script when it's actually stuck on graphics handshaking.
%
% This file, placed in the same folder as your scripts, SHADOWS the
% real waitbar() (MATLAB checks the current folder before its own
% toolbox folders for non-built-in functions like this one). It just
% returns a harmless sentinel number instead of creating any real
% graphics object, so no timeout can ever occur.
%
% Paired with close.m in this same folder, which ignores this sentinel
% but forwards every other call to the real close() untouched -- so
% real figures elsewhere in your project still close normally.
h = 12345; % arbitrary sentinel "handle" -- never a real graphics object
end