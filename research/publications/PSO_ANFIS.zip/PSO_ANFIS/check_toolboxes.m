%% check_toolboxes.m -- run this FIRST, takes 1 second
fprintf('Fuzzy Logic Toolbox:        %d\n', license('test','Fuzzy_Logic_Toolbox'));
fprintf('Global Optimization Toolbox: %d\n', license('test','GADS_Toolbox'));
fprintf('Statistics & ML Toolbox:    %d\n', license('test','Statistics_Toolbox'));
fprintf('(1 = installed/licensed, 0 = NOT available -- if any show 0,\n');
fprintf('that alone could explain slowness/failure, not just problem size.)\n');