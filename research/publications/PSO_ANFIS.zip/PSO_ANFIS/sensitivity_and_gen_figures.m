%% sensitivity_and_gen_figures.m
% ================================================================
% FIGURE 9: Sensitivity/robustness to injected noise level
% FIGURE 10: Generalization bar chart (trained vs unseen)
% ================================================================
% Run AFTER full_comparison.m and generalization_test.m (the latter
% must have been updated to save table3_generalization.csv).

clear; clc; close all;
cfg = config_planter();

%% ================= FIGURE 9: SENSITIVITY TO NOISE LEVEL =================
fprintf('=== Figure 9: Sensitivity to injected noise level ===\n');
fprintf('This retrains models at several noise levels -- takes a while.\n');

noiseLevels = [0.5, 1.0, 1.2, 1.8, 2.5]; % multiplier on cfg.noiseStdDistance
methodsToTest = {'ANFIS_Hybrid', 'PSO_ANFIS_Proposed'};
sensResults = struct();
for mi = 1:numel(methodsToTest)
    sensResults.(methodsToTest{mi}) = zeros(size(noiseLevels));
end

for ni = 1:numel(noiseLevels)
    rng(42);
    noiseMult = noiseLevels(ni);
    fprintf('\n-- Noise level x%.2f --\n', noiseMult);

    % Regenerate dataset at this noise level (self-contained, does not
    % overwrite your actual planter_dataset.mat)
    dataN = table(); row = 1;
    for c = 1:numel(cfg.cropIDs)
        base = cfg.baseline.(cfg.cropNames{c});
        for s = 1:numel(cfg.soilIDs)
            adj = cfg.soilAdjust(cfg.soilNames{s});
            meanD = base.distance * adj.distanceFactor;
            for k = 1:cfg.nSamplesPerCombo
                nD = meanD + (cfg.noiseStdDistance*noiseMult)*randn();
                nD = max(cfg.minDistance_cm, nD);
                dataN.Crop(row) = cfg.cropIDs(c); dataN.SoilType(row) = cfg.soilIDs(s);
                dataN.Distance_cm(row) = nD; row = row+1;
            end
        end
    end
    X = [dataN.Crop, dataN.SoilType]; y = dataN.Distance_cm; N = height(dataN);
    idx = randperm(N); nTrain = round(cfg.trainSplit*N); nVal = round(cfg.valSplit*N);
    trainIdx = idx(1:nTrain); valIdx = idx(nTrain+1:nTrain+nVal); testIdx = idx(nTrain+nVal+1:end);
    Xtr=X(trainIdx,:); ytr=y(trainIdx); Xv=X(valIdx,:); yv=y(valIdx); Xte=X(testIdx,:); yte=y(testIdx);

    % ANFIS Hybrid
    opts = genfisOptions('SubtractiveClustering','ClusterInfluenceRange', cfg.clusterInfluence);
    initFis = genfis(Xtr, ytr, opts);
    anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', cfg.anfisEpochs, 'OptimizationMethod', 0, ...
        'ValidationData',[Xv,yv],'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
    [fisH,~,~,chkH,chkErrH] = anfis([Xtr,ytr], anfisOpt);
    if ~isempty(chkErrH), fisH = chkH; end
    predH = evalfis(fisH, Xte);
    sensResults.ANFIS_Hybrid(ni) = sqrt(mean((yte-predH).^2));

    % PSO-ANFIS Proposed (rule-structure PSO, shortened for this sweep)
    fitFcn = @(p) localFitness(p, Xtr, ytr, Xv, yv);
    [bestP,~] = particleswarm(fitFcn, 2, [0.3,0.8], [1.2,2.0], ...
        optimoptions('particleswarm','SwarmSize',25,'MaxIterations',30,'Display','off'));
    optsP = genfisOptions('SubtractiveClustering','ClusterInfluenceRange',bestP(1),'SquashFactor',bestP(2));
    initFisP = genfis(Xtr, ytr, optsP);
    anfisOptP = anfisOptions('InitialFIS', initFisP, 'EpochNumber', cfg.anfisEpochs, 'OptimizationMethod', 0, ...
        'ValidationData',[Xv,yv],'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
    [fisP,~,~,chkP,chkErrP] = anfis([Xtr,ytr], anfisOptP);
    if ~isempty(chkErrP), fisP = chkP; end
    predP = evalfis(fisP, Xte);
    sensResults.PSO_ANFIS_Proposed(ni) = sqrt(mean((yte-predP).^2));
end

fig9 = figure('Name','Sensitivity to Noise Level','Visible','on');
hold on;
plot(noiseLevels, sensResults.ANFIS_Hybrid, '-o', 'LineWidth',2, 'DisplayName','ANFIS (Hybrid)');
plot(noiseLevels, sensResults.PSO_ANFIS_Proposed, '-s', 'LineWidth',2, 'DisplayName','PSO-ANFIS (Proposed)');
xlabel('Injected noise multiplier (x baseline std)'); ylabel('Test RMSE (cm)');
title('Robustness to Increasing Data Noise'); legend show; grid on;
saveas(fig9, 'fig9_sensitivity_noise.png');
sensTable = table(noiseLevels', sensResults.ANFIS_Hybrid', sensResults.PSO_ANFIS_Proposed', ...
    'VariableNames', {'NoiseMultiplier','RMSE_ANFIS_Hybrid','RMSE_PSO_ANFIS_Proposed'});
writetable(sensTable, 'fig9_sensitivity_data.csv');

%% ================= FIGURE 10: GENERALIZATION BAR CHART =================
fprintf('\n=== Figure 10: Generalization bar chart ===\n');
try
    genTable = readtable('table3_generalization.csv');
    fig10 = figure('Name','Generalization: Trained vs Unseen','Visible','on');
    colors_ = zeros(height(genTable),3);
    for i=1:height(genTable)
        if genTable.TrainedOn(i), colors_(i,:) = [0.2 0.6 0.9]; else, colors_(i,:) = [0.9 0.3 0.2]; end
    end
    b = bar(categorical(genTable.Type), genTable.RMSE);
    b.FaceColor = 'flat'; b.CData = colors_;
    ylabel('RMSE (cm)'); title('Generalization: Trained (blue) vs Unseen/Extrapolated (red)');
    xtickangle(20); grid on;
    saveas(fig10, 'fig10_generalization_barchart.png');
catch
    warning('table3_generalization.csv not found -- run the updated generalization_test.m first.');
end

fprintf('\nDone. fig9_sensitivity_noise.png and fig10_generalization_barchart.png saved.\n');

function rmse = localFitness(params, Xtr, ytr, Xv, yv)
    try
        opts = genfisOptions('SubtractiveClustering','ClusterInfluenceRange',params(1),'SquashFactor',params(2));
        initFis = genfis(Xtr, ytr, opts);
        anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', 10, 'OptimizationMethod', 0, ...
            'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
        fis = anfis([Xtr,ytr], anfisOpt);
        pred = evalfis(fis, Xv);
        rmse = sqrt(mean((yv-pred).^2));
        if ~isfinite(rmse), rmse = 1e6; end
    catch
        rmse = 1e6;
    end
end