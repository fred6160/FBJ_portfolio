%% build_tables_and_figures.m
% ================================================================
% Loads full_comparison_results.mat (from full_comparison.m) and
% produces every table + figure requested for the paper that is
% legitimately computable from simulation results.
%
% NOT produced here (requires real hardware measurement -- see
% planter_latency_test.ino and the bench-test protocol notes):
%   - Inference latency (ms/decision) on actual Arduino
%   - Memory footprint (flash/RAM)
%   - Hardware-in-the-loop figure
% ================================================================

clear; clc; close all;
load('full_comparison_results.mat');
convergenceTraces = readtable('convergence_traces.csv');
cfg = config_planter();

%% ================= TABLE 1: MAIN COMPARISON TABLE =================
fprintf('=== Building Table 1: Main Comparison Table ===\n');
mainTable = table();
row = 1;
for m = 1:numel(methodNames)
    mn = methodNames{m};
    rD = allResults.Distance_cm.(mn);
    rS = allResults.Seeds.(mn);
    mainTable.Method(row) = string(mn);
    mainTable.RMSE_Spacing(row) = mean(rD.rmse, 'omitnan');
    mainTable.RMSE_SeedCount(row) = mean(rS.rmse, 'omitnan');
    mainTable.MAE_Spacing(row) = mean(rD.mae, 'omitnan');
    mainTable.MAE_SeedCount(row) = mean(rS.mae, 'omitnan');
    mainTable.R2_Spacing(row) = mean(rD.r2, 'omitnan');
    mainTable.R2_SeedCount(row) = mean(rS.r2, 'omitnan');
    mainTable.MeanTrainTime_s(row) = mean(rD.trainTime, 'omitnan');
    mainTable.Std_RMSE_Spacing(row) = std(rD.rmse, 'omitnan');
    mainTable.RuleCount(row) = round(mean(rD.ruleCount, 'omitnan'));
    row = row + 1;
end
writetable(mainTable, 'table1_main_comparison.csv');
disp(mainTable);

%% ================= TABLE 2: ABLATION TABLE =================
fprintf('\n=== Building Table 2: Ablation Table ===\n');
ablationMethods = {'ANFIS_Hybrid','PSO_ANFIS_RuleOnly','PSO_ANFIS_Proposed'};
ablationLabels = {'Baseline (no PSO)','Rule-structure only','Rule-structure + premise (proposed)'};
ablationTable = table();
for i = 1:numel(ablationMethods)
    mn = ablationMethods{i};
    rD = allResults.Distance_cm.(mn);
    ablationTable.PSO_Target(i) = string(ablationLabels{i});
    ablationTable.RMSE(i) = mean(rD.rmse, 'omitnan');
    ablationTable.RuleCount(i) = round(mean(rD.ruleCount, 'omitnan'));
    ablationTable.TrainTime_s(i) = mean(rD.trainTime, 'omitnan');
end
writetable(ablationTable, 'table2_ablation.csv');
disp(ablationTable);

%% ================= CV OF SPACING + CLASSIFICATION METRICS (per method) =================
fprintf('\n=== Computing CV of spacing + Seed-count classification metrics ===\n');
extraMetrics = table();
for m = 1:numel(methodNames)
    mn = methodNames{m};
    predD = allResults.Distance_cm.(mn).predTest{1}; % first run, representative
    actualD = allResults.Distance_cm.(mn).actualTest{1};
    predS = round(min(max(allResults.Seeds.(mn).predTest{1}, cfg.minSeeds), cfg.maxSeeds));
    actualS = allResults.Seeds.(mn).actualTest{1};

    % --- CV of spacing (simulated proxy -- see limitations note ---
    % TRUE agronomic CV requires physically measured hole-to-hole
    % distances from a real planter run; this is the model-prediction
    % variability proxy, not the field metric. State this explicitly.
    cv_spacing = (std(predD) / mean(predD)) * 100;

    % --- Classification metrics on rounded seed count ---
    classes = unique(actualS);
    accuracy = mean(predS == actualS) * 100;
    precisions = zeros(size(classes)); recalls = zeros(size(classes)); f1s = zeros(size(classes));
    for c = 1:numel(classes)
        cls = classes(c);
        tp = sum(predS==cls & actualS==cls);
        fp = sum(predS==cls & actualS~=cls);
        fn = sum(predS~=cls & actualS==cls);
        precisions(c) = tp / max(tp+fp, 1);
        recalls(c) = tp / max(tp+fn, 1);
        f1s(c) = 2*precisions(c)*recalls(c) / max(precisions(c)+recalls(c), eps);
    end
    macroP = mean(precisions); macroR = mean(recalls); macroF1 = mean(f1s);

    % --- Multiple-index / miss-index (singulation-style metrics) ---
    skipPct = mean(predS < actualS) * 100;   % under-dropped
    doublePct = mean(predS > actualS) * 100; % over-dropped
    correctPct = mean(predS == actualS) * 100;

    extraMetrics.Method(m) = string(mn);
    extraMetrics.CV_Spacing_pct(m) = cv_spacing;
    extraMetrics.Accuracy_pct(m) = accuracy;
    extraMetrics.MacroPrecision(m) = macroP;
    extraMetrics.MacroRecall(m) = macroR;
    extraMetrics.MacroF1(m) = macroF1;
    extraMetrics.SkipPct(m) = skipPct;
    extraMetrics.DoublePct(m) = doublePct;
    extraMetrics.CorrectSingulationPct(m) = correctPct;

    % Confusion matrix saved per method
    try
        cm = confusionmat(actualS, predS);
        writematrix(cm, sprintf('confusion_matrix_%s.csv', mn));
    catch
        warning('confusionmat requires Statistics and Machine Learning Toolbox.');
    end
end
writetable(extraMetrics, 'table_extra_metrics_CV_classification_singulation.csv');
disp(extraMetrics);

%% ================= FIGURE 1: PSO/GA/GWO CONVERGENCE PLOT =================
fprintf('\n=== Figure 1: Convergence plot ===\n');
fig1 = figure('Name','Convergence Comparison','Visible','on');
methods_conv = unique(convergenceTraces.Method);
colors_ = lines(numel(methods_conv));
hold on;
for i = 1:numel(methods_conv)
    sub = convergenceTraces(strcmp(convergenceTraces.Method, methods_conv(i)), :);
    maxIter = max(sub.Iteration);
    meanCurve = zeros(1,maxIter); stdCurve = zeros(1,maxIter);
    for it_ = 1:maxIter
        vals = sub.BestFitness(sub.Iteration==it_);
        meanCurve(it_) = mean(vals); stdCurve(it_) = std(vals);
    end
    xline_ = 1:maxIter;
    fill([xline_, fliplr(xline_)], [meanCurve+stdCurve, fliplr(meanCurve-stdCurve)], colors_(i,:), ...
        'FaceAlpha',0.15,'EdgeColor','none','HandleVisibility','off');
    plot(xline_, meanCurve, 'Color', colors_(i,:), 'LineWidth',2, 'DisplayName', methods_conv(i));
end
xlabel('Iteration'); ylabel('Best Fitness (Validation RMSE)');
title('Convergence: mean \pm std across runs'); legend show; grid on;
saveas(fig1, 'fig1_convergence.png');

%% ================= FIGURE 2: MF BEFORE/AFTER PSO =================
fprintf('=== Figure 2: MF before/after ===\n');
if isfield(savedFIS,'before') && isfield(savedFIS,'after')
    fig2 = figure('Name','MF Before vs After PSO','Visible','on');
    subplot(2,1,1); plotmf(savedFIS.before, 'input', 1); title('Crop MFs -- BEFORE (initial genfis)');
    subplot(2,1,2); plotmf(savedFIS.after, 'input', 1); title('Crop MFs -- AFTER (PSO-tuned, proposed)');
    saveas(fig2, 'fig2_mf_before_after.png');
else
    warning('savedFIS.before/after not found -- check full_comparison.m saved them correctly.');
end

%% ================= FIGURE 3: PREDICTED VS ACTUAL (proposed method) =================
fprintf('=== Figure 3: Predicted vs actual (proposed) ===\n');
fig3 = figure('Name','Predicted vs Actual - Proposed Method','Visible','on');
subplot(1,2,1);
pD = allResults.Distance_cm.PSO_ANFIS_Proposed.predTest{1};
aD = allResults.Distance_cm.PSO_ANFIS_Proposed.actualTest{1};
plot(aD, pD, 'bo'); hold on; plot([min(aD) max(aD)],[min(aD) max(aD)],'r--');
xlabel('Actual Distance (cm)'); ylabel('Predicted Distance (cm)'); title('Distance: Proposed Method'); grid on;
subplot(1,2,2);
pS = allResults.Seeds.PSO_ANFIS_Proposed.predTest{1};
aS = allResults.Seeds.PSO_ANFIS_Proposed.actualTest{1};
plot(aS, pS, 'bo'); hold on; plot([min(aS) max(aS)],[min(aS) max(aS)],'r--');
xlabel('Actual Seeds'); ylabel('Predicted Seeds'); title('Seeds: Proposed Method'); grid on;
saveas(fig3, 'fig3_predicted_vs_actual.png');

%% ================= FIGURE 4: RESIDUAL PLOTS =================
fprintf('=== Figure 4: Residual plots ===\n');
fig4 = figure('Name','Residuals - Proposed Method','Visible','on');
subplot(1,2,1); scatter(pD, aD-pD, 20,'filled'); yline(0,'r--'); xlabel('Predicted Distance (cm)'); ylabel('Residual'); title('Distance Residuals'); grid on;
subplot(1,2,2); scatter(pS, aS-pS, 20,'filled'); yline(0,'r--'); xlabel('Predicted Seeds'); ylabel('Residual'); title('Seed Count Residuals'); grid on;
saveas(fig4, 'fig4_residuals.png');

%% ================= FIGURE 5: BOXPLOT OF RMSE ACROSS RUNS =================
fprintf('=== Figure 5: Boxplot of RMSE across runs ===\n');
fig5 = figure('Name','RMSE Boxplot','Visible','on');
rmseMatrix = []; groupLabels = {};
for m = 1:numel(methodNames)
    r_ = allResults.Distance_cm.(methodNames{m}).rmse;
    rmseMatrix = [rmseMatrix, r_(:)]; %#ok<AGROW>
end
boxplot(rmseMatrix, 'Labels', methodNames);
ylabel('RMSE (Distance, cm)'); title('RMSE Distribution Across Runs by Method'); grid on;
xtickangle(30);
saveas(fig5, 'fig5_rmse_boxplot.png');

%% ================= FIGURE 6: CV BAR CHART =================
fprintf('=== Figure 6: CV bar chart ===\n');
fig6 = figure('Name','CV of Spacing by Method','Visible','on');
bar(categorical(extraMetrics.Method), extraMetrics.CV_Spacing_pct);
ylabel('CV of Spacing (%)'); title('Spacing Uniformity (simulated proxy) by Method'); grid on;
saveas(fig6, 'fig6_cv_barchart.png');

%% ================= FIGURE 7: RULE COUNT BEFORE/AFTER =================
fprintf('=== Figure 7: Rule count comparison ===\n');
fig7 = figure('Name','Rule Count by Method','Visible','on');
ruleCounts = mainTable.RuleCount;
bar(categorical(mainTable.Method), ruleCounts);
ylabel('Number of Rules'); title('Rule Base Size by Method'); grid on;
saveas(fig7, 'fig7_rulecount.png');

fprintf('\nAll tables and figures saved to current directory.\n');
fprintf('Figures 8 (hardware-in-the-loop) and the exact hardware latency/\n');
fprintf('memory numbers for Table 1 require REAL measurement -- see\n');
fprintf('planter_latency_test.ino and run it on your actual Arduino Mega.\n');