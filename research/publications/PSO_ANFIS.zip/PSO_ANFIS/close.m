function close(varargin)
% CLOSE override -- passes through to the REAL close() for everything
% except our waitbar.m sentinel handle (12345), which it just ignores.
% This keeps normal figure-closing behavior working everywhere else in
% your project while specifically neutralizing the fake waitbar handle.
if nargin >= 1 && isnumeric(varargin{1}) && isequal(varargin{1}, 12345)
    return; % our dummy waitbar handle -- nothing real to close
end
builtin('close', varargin{:});
end