%% full_comparison.m
% ================================================================
% FULL METHOD COMPARISON: Lookup / ANFIS / GA-ANFIS / GWO-ANFIS /
% PSO-ANFIS (rule-structure only) / PSO-ANFIS (proposed, combined)
% ================================================================
% Produces every metric/table that IS legitimately computable in
% simulation. Does NOT produce: hardware inference latency, memory
% footprint, or the hardware-in-the-loop figure -- those require a
% real physical measurement (see planter_latency_test.ino, provided
% separately, and the bench-test protocol notes at the end of this
% file's console output).
%
% REQUIRES: Fuzzy Logic Toolbox, Global Optimization Toolbox
% (particleswarm AND ga), Statistics and Machine Learning Toolbox.
% Same execute-verify caveat as before applies to tunefis/
% getTunableSettings calls (Arms using tunefis).
%
% RUNTIME WARNING: this trains many ANFIS models per run (Lookup is
% free, but ANFIS/GA/GWO/PSO each retrain fully). With N_RUNS=20 this
% can take a long time -- see the earlier lesson about silent-looking
% "stuck" training. Progress is printed per run/method below so it is
% never silent.
% ================================================================

clear; clc;
cfg = config_planter();
load('planter_dataset.mat', 'data');

N_RUNS = 8;  % reduced from 20 for practical runtime -- see comment below
seedList = 100 + (1:N_RUNS);

% Agronomic assumptions ADDED for this analysis only (not part of the
% original config_planter.m / prior chapter -- flagged as new,
% separate assumptions specific to this paper's population-precision
% metric). CITE REAL SOURCES for these in the paper rather than
% treating these as validated.
rowSpacing_cm = struct('Groundnut', 50, 'Maize', 75, 'Wheat', 18); % inter-row spacing
targetPopulation_perHa = struct('Groundnut', 120000, 'Maize', 53000, 'Wheat', 250000); % illustrative

psoBounds_lb = [0.3, 0.8]; psoBounds_ub = [1.2, 2.0]; % [ClusterInfluenceRange, SquashFactor]

outputVars = {'Distance_cm', 'Seeds'};
methodNames = {'Lookup','ANFIS_Hybrid','GA_ANFIS','GWO_ANFIS','PSO_ANFIS_RuleOnly','PSO_ANFIS_Proposed'};

allResults = struct();
convergenceTraces = table(); % long format: Method, Run, Iteration, BestFitness
savedFIS = struct(); % store one representative before/after FIS per output for MF plots

for ov = 1:numel(outputVars)
    outVar = outputVars{ov};
    fprintf('\n\n#################### OUTPUT VARIABLE: %s ####################\n', outVar);

    for m = 1:numel(methodNames)
        allResults.(outVar).(methodNames{m}).rmse = [];
        allResults.(outVar).(methodNames{m}).mae = [];
        allResults.(outVar).(methodNames{m}).r2 = [];
        allResults.(outVar).(methodNames{m}).trainTime = [];
        allResults.(outVar).(methodNames{m}).ruleCount = [];
        allResults.(outVar).(methodNames{m}).predTest = {};
        allResults.(outVar).(methodNames{m}).actualTest = {};
    end

    for r = 1:N_RUNS
        rng(seedList(r));
        fprintf('\n--- %s | RUN %d/%d (seed=%d) ---\n', outVar, r, N_RUNS, seedList(r));

        X = [data.Crop, data.SoilType];
        y = data.(outVar);
        N = height(data);
        idx = randperm(N);
        nTrain = round(cfg.trainSplit*N); nVal = round(cfg.valSplit*N);
        trainIdx = idx(1:nTrain); valIdx = idx(nTrain+1:nTrain+nVal); testIdx = idx(nTrain+nVal+1:end);
        Xtr = X(trainIdx,:); ytr = y(trainIdx); Xv = X(valIdx,:); yv = y(valIdx);
        Xte = X(testIdx,:); yte = y(testIdx);
        trainData = [Xtr, ytr]; checkData = [Xv, yv];

        % ============ METHOD 1: LOOKUP TABLE (naive baseline) ============
        t0 = tic;
        lookupMeans = containers.Map('KeyType','char','ValueType','double');
        combos = unique(Xtr, 'rows');
        for ci = 1:size(combos,1)
            mask = Xtr(:,1)==combos(ci,1) & Xtr(:,2)==combos(ci,2);
            lookupMeans(sprintf('%d_%d',combos(ci,1),combos(ci,2))) = mean(ytr(mask));
        end
        predLookup = zeros(size(yte));
        for i = 1:numel(yte)
            key = sprintf('%d_%d', Xte(i,1), Xte(i,2));
            if isKey(lookupMeans, key), predLookup(i) = lookupMeans(key); else, predLookup(i) = mean(ytr); end
        end
        tLookup = toc(t0);
        fprintf('  [Lookup] done in %.2fs\n', tLookup);
        allResults = logResult(outVar,'Lookup', yte, predLookup, tLookup, NaN, allResults);

        % ============ METHOD 2: ANFIS HYBRID BASELINE ============
        t0 = tic;
        opts = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', cfg.clusterInfluence);
        initFis = genfis(Xtr, ytr, opts);
        anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', cfg.anfisEpochs, ...
            'ErrorGoal', cfg.anfisErrorGoal, 'OptimizationMethod', 0, 'ValidationData', checkData, ...
            'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
        [fisH, ~, ~, chkFisH, chkErrH] = anfis(trainData, anfisOpt);
        fisH_best = chkFisH; if isempty(chkErrH), fisH_best = fisH; end
        tHybrid = toc(t0);
        fprintf('  [ANFIS_Hybrid] done in %.2fs\n', tHybrid);
        predHybrid = evalfis(fisH_best, Xte);
        allResults = logResult(outVar,'ANFIS_Hybrid', yte, predHybrid, tHybrid, numel(fisH_best.Rules), allResults);
        if r==1 && strcmp(outVar,'Distance_cm'), savedFIS.before = initFis; end

        % ============ METHOD 3: GA-ANFIS (rule-structure search via GA) ============
        t0 = tic;
        fitFcn = @(p) ruleStructureFitness(p, Xtr, ytr, Xv, yv);
        gaOpt = optimoptions('ga', 'PopulationSize', 12, 'MaxGenerations', 12, 'Display','iter');
        [bestGA, ~, ~, gaOutput] = ga(fitFcn, 2, [],[],[],[], psoBounds_lb, psoBounds_ub, [], gaOpt);
        [fisGA, ruleCountGA] = trainWithParams(bestGA, Xtr, ytr, checkData, cfg);
        tGA = toc(t0);
        fprintf('  [GA_ANFIS] done in %.2fs\n', tGA);
        predGA = evalfis(fisGA, Xte);
        allResults = logResult(outVar,'GA_ANFIS', yte, predGA, tGA, ruleCountGA, allResults);

        % ============ METHOD 4: GWO-ANFIS (custom Grey Wolf Optimizer) ============
        t0 = tic;
        [bestGWO, gwoTrace] = grayWolfOptimizer(fitFcn, psoBounds_lb, psoBounds_ub, 12, 12);
        [fisGWO, ruleCountGWO] = trainWithParams(bestGWO, Xtr, ytr, checkData, cfg);
        tGWO = toc(t0);
        fprintf('  [GWO_ANFIS] done in %.2fs\n', tGWO);
        predGWO = evalfis(fisGWO, Xte);
        allResults = logResult(outVar,'GWO_ANFIS', yte, predGWO, tGWO, ruleCountGWO, allResults);
        if strcmp(outVar,'Distance_cm')
            for it_ = 1:numel(gwoTrace)
                convergenceTraces = [convergenceTraces; {"GWO_ANFIS", r, it_, gwoTrace(it_)}]; %#ok<AGROW>
            end
        end

        % ============ METHOD 5: PSO-ANFIS (rule-structure only) ============
        t0 = tic;
        psoOptions_ = optimoptions('particleswarm', 'SwarmSize', 12, 'MaxIterations', 12, ...
            'Display','iter','OutputFcn',@psoTraceCapture);
        clear psoTraceCapture; % reset persistent state
        [bestPSO, ~] = particleswarm(fitFcn, 2, psoBounds_lb, psoBounds_ub, psoOptions_);
        psoTrace = psoTraceCapture([], 'get');
        [fisPSO, ruleCountPSO] = trainWithParams(bestPSO, Xtr, ytr, checkData, cfg);
        tPSO = toc(t0);
        fprintf('  [PSO_ANFIS_RuleOnly] done in %.2fs\n', tPSO);
        predPSO = evalfis(fisPSO, Xte);
        allResults = logResult(outVar,'PSO_ANFIS_RuleOnly', yte, predPSO, tPSO, ruleCountPSO, allResults);
        if strcmp(outVar,'Distance_cm')
            for it_ = 1:numel(psoTrace)
                convergenceTraces = [convergenceTraces; {"PSO_ANFIS_RuleOnly", r, it_, psoTrace(it_)}]; %#ok<AGROW>
            end
        end

        % ============ METHOD 6: PSO-ANFIS PROPOSED (rule-structure THEN premise via tunefis) ============
        t0 = tic;
        try
            fisProposed_stage1 = fisPSO; % start from the PSO-optimized rule-structure model above
            premiseSettings = getTunableSettings(fisProposed_stage1.Inputs);
            tunerOpts = tunefisOptions('Method', 'particleswarm');
            tunerOpts.MethodOptions.SwarmSize = 12;
            tunerOpts.MethodOptions.MaxIterations = 12;
            fisProposed = tunefis(fisProposed_stage1, premiseSettings, Xtr, ytr, tunerOpts);
            tProposed = toc(t0);
            fprintf('  [PSO_ANFIS_Proposed] done in %.2fs\n', tProposed);
            predProposed = evalfis(fisProposed, Xte);
            allResults = logResult(outVar,'PSO_ANFIS_Proposed', yte, predProposed, tProposed, numel(fisProposed.Rules), allResults);
            if r==1 && strcmp(outVar,'Distance_cm'), savedFIS.after = fisProposed; end
        catch ME
            warning('Proposed method (tunefis) failed: %s', ME.message);
            allResults = logResult(outVar,'PSO_ANFIS_Proposed', yte, nan(size(yte)), NaN, NaN, allResults);
        end
    end
end

convergenceTraces.Properties.VariableNames = {'Method','Run','Iteration','BestFitness'};
writetable(convergenceTraces, 'convergence_traces.csv');
save('full_comparison_results.mat', 'allResults', 'savedFIS', 'methodNames', 'outputVars', 'rowSpacing_cm', 'targetPopulation_perHa');
fprintf('\nSaved: convergence_traces.csv, full_comparison_results.mat\n');
fprintf('Next: run build_tables_and_figures.m to produce the three paper tables and all figures.\n');


%% ================= LOCAL FUNCTIONS (must stay at file end) =================
function S = logResult(outVar, methodName, yActual, yPred, trainTime, ruleCount, S)
    % Computes metrics and appends them into the results struct S,
    % which is returned and must be reassigned at the call site:
    %   allResults = logResult(..., allResults);
    % (Standard MATLAB pass-by-value semantics -- no assignin/evalin
    % trickery needed; this is the safe, idiomatic pattern.)
    err = yActual - yPred;
    rmse = sqrt(mean(err.^2, 'omitnan'));
    mae = mean(abs(err), 'omitnan');
    ssRes = sum(err.^2, 'omitnan'); ssTot = sum((yActual-mean(yActual,'omitnan')).^2, 'omitnan');
    r2 = 1 - ssRes/ssTot;
    S.(outVar).(methodName).rmse(end+1) = rmse;
    S.(outVar).(methodName).mae(end+1) = mae;
    S.(outVar).(methodName).r2(end+1) = r2;
    S.(outVar).(methodName).trainTime(end+1) = trainTime;
    S.(outVar).(methodName).ruleCount(end+1) = ruleCount;
    S.(outVar).(methodName).predTest{end+1} = yPred;
    S.(outVar).(methodName).actualTest{end+1} = yActual;
end

function rmse = ruleStructureFitness(params, Xtr, ytr, Xv, yv)
    try
        opts = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', params(1), 'SquashFactor', params(2));
        initFis = genfis(Xtr, ytr, opts);
        anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', 8, 'OptimizationMethod', 0, ...
            'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
        fis = anfis([Xtr, ytr], anfisOpt);
        pred = evalfis(fis, Xv);
        rmse = sqrt(mean((yv-pred).^2));
        if ~isfinite(rmse), rmse = 1e6; end
    catch
        rmse = 1e6;
    end
end

function [fis, ruleCount] = trainWithParams(params, Xtr, ytr, checkData, cfg)
    opts = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', params(1), 'SquashFactor', params(2));
    initFis = genfis(Xtr, ytr, opts);
    anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', cfg.anfisEpochs, 'OptimizationMethod', 0, ...
        'ValidationData', checkData, 'DisplayANFISInformation',0,'DisplayErrorValues',0, ...
        'DisplayStepSize',0,'DisplayFinalResults',0);
    [fis, ~, ~, chkFis, chkErr] = anfis([Xtr, ytr], anfisOpt);
    if ~isempty(chkErr), fis = chkFis; end
    ruleCount = numel(fis.Rules);
end

function stop = psoTraceCapture(optimValues, state)
    % OutputFcn for particleswarm: captures best fitness per iteration
    % into a persistent variable, retrieved afterward via the 'get' flag.
    % Called two ways:
    %   (1) By particleswarm itself: psoTraceCapture(optimValues, 'iter'/'init'/'done')
    %   (2) Manually to retrieve the trace: psoTraceCapture([], 'get')
    persistent trace
    if ischar(state) && strcmp(state, 'get')
        stop = trace; % repurposed return value to fetch the trace
        return
    end
    stop = false;
    switch state
        case 'init'
            trace = [];
        case 'iter'
            trace(end+1) = optimValues.bestfval; %#ok<AGROW>
    end
end

function [bestParams, trace] = grayWolfOptimizer(fitFcn, lb, ub, nWolves, maxIter)
    % Minimal Grey Wolf Optimizer implementation (MATLAB has no
    % built-in GWO -- this is a standard-form custom implementation
    % following Mirjalili et al. 2014, simplified for 2 continuous
    % variables). Verify against the canonical algorithm if citing
    % this implementation's fidelity in the paper.
    dim = numel(lb);
    positions = lb + rand(nWolves, dim) .* (ub - lb);
    fitness = arrayfun(@(i) fitFcn(positions(i,:)), 1:nWolves);
    trace = zeros(1, maxIter);
    fprintf('  GWO progress: ');
    for t = 1:maxIter
        [~, sortIdx] = sort(fitness);
        alpha = positions(sortIdx(1),:); beta = positions(sortIdx(2),:); delta = positions(sortIdx(3),:);
        a = 2 - t*(2/maxIter);
        for i = 1:nWolves
            for d = 1:dim
                r1=rand; r2=rand; A1=2*a*r1-a; C1=2*r2;
                Dalpha = abs(C1*alpha(d) - positions(i,d)); X1 = alpha(d) - A1*Dalpha;
                r1=rand; r2=rand; A2=2*a*r1-a; C2=2*r2;
                Dbeta = abs(C2*beta(d) - positions(i,d)); X2 = beta(d) - A2*Dbeta;
                r1=rand; r2=rand; A3=2*a*r1-a; C3=2*r2;
                Ddelta = abs(C3*delta(d) - positions(i,d)); X3 = delta(d) - A3*Ddelta;
                positions(i,d) = (X1+X2+X3)/3;
            end
            positions(i,:) = min(max(positions(i,:), lb), ub);
        end
        fitness = arrayfun(@(i) fitFcn(positions(i,:)), 1:nWolves);
        trace(t) = min(fitness);
        fprintf('.');
    end
    fprintf(' done (best=%.4f)\n', min(fitness));
    [~, bestIdx] = min(fitness);
    bestParams = positions(bestIdx,:);
end