%% quick_core_results.m
% ================================================================
% MINIMAL, FAST, RELIABLE CORE RESULT: ANFIS (Hybrid baseline) vs
% PSO-ANFIS (proposed). This is deliberately scoped down to ONLY the
% comparison that actually matters for the paper's central claim --
% GA-ANFIS / GWO-ANFIS / the 4-arm ablation can be added LATER as
% extended evaluation once you have this working and have a draft
% underway. Do not block paper-writing on the bigger comparison.
%
% DESIGN CHOICES FOR SPEED + RELIABILITY:
%  - Hand-rolled PSO (not particleswarm) -- removes any dependency on
%    Global Optimization Toolbox being licensed/available, which is a
%    possible silent cause of the earlier slowness/failure.
%  - No tunefis calls at all -- removes the one part of the earlier
%    scripts I could not execute-verify myself.
%  - Small swarm (10 particles x 10 iterations = 100 evaluations).
%  - N_RUNS = 5 (enough for a mean +/- std and a basic paired test;
%    bump up later if you have time before the deadline).
%  - INCREMENTAL SAVING: results are written to CSV after EVERY run,
%    not just at the end. If you stop this early, whatever completed
%    is still usable -- open quick_results_Distance.csv /
%    quick_results_Seeds.csv at any time to see progress so far.
%  - Verbose progress: prints before AND after every single training
%    call, so silence for more than ~10-15 seconds at a time would be
%    a genuine red flag worth reporting back, not just "might be slow."
% ================================================================

clear; clc;
cfg = config_planter();
load('planter_dataset.mat', 'data');

N_RUNS = 5;
seedList = 100 + (1:N_RUNS);
outputVars = {'Distance_cm', 'Seeds'};

for ov = 1:numel(outputVars)
    outVar = outputVars{ov};
    resultsFile = sprintf('quick_results_%s.csv', outVar);
    fprintf('\n\n#################### %s ####################\n', outVar);

    % Start the results file fresh with a header, so partial runs are
    % readable even if this script is stopped early.
    resultsTable = table('Size',[0 7], ...
        'VariableTypes', {'double','string','double','double','double','double','double'}, ...
        'VariableNames', {'Run','Method','RMSE','MAE','R2','TrainTime_s','BestPSOParams_str'});
    writetable(resultsTable, resultsFile);

    for r = 1:N_RUNS
        rng(seedList(r));
        fprintf('\n=== %s | RUN %d/%d (seed=%d) ===\n', outVar, r, N_RUNS, seedList(r));

        X = [data.Crop, data.SoilType];
        y = data.(outVar);
        N = height(data);
        idx = randperm(N);
        nTrain = round(cfg.trainSplit*N); nVal = round(cfg.valSplit*N);
        trainIdx = idx(1:nTrain); valIdx = idx(nTrain+1:nTrain+nVal); testIdx = idx(nTrain+nVal+1:end);
        Xtr = X(trainIdx,:); ytr = y(trainIdx); Xv = X(valIdx,:); yv = y(valIdx);
        Xte = X(testIdx,:); yte = y(testIdx);
        trainData = [Xtr, ytr]; checkData = [Xv, yv];

        % ---------------- METHOD 1: ANFIS HYBRID BASELINE ----------------
        fprintf('  [ANFIS_Hybrid] starting...\n'); t0 = tic;
        opts = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', cfg.clusterInfluence);
        initFis = genfis(Xtr, ytr, opts);
        anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', cfg.anfisEpochs, ...
            'ErrorGoal', cfg.anfisErrorGoal, 'OptimizationMethod', 0, 'ValidationData', checkData, ...
            'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
        [fisH, ~, ~, chkFisH, chkErrH] = anfis(trainData, anfisOpt);
        fisH_best = chkFisH; if isempty(chkErrH), fisH_best = fisH; end
        tHybrid = toc(t0);
        predH = evalfis(fisH_best, Xte);
        [rmseH, maeH, r2H] = computeMetrics(yte, predH);
        fprintf('  [ANFIS_Hybrid] DONE in %.1fs | RMSE=%.4f MAE=%.4f R2=%.4f\n', tHybrid, rmseH, maeH, r2H);
        appendRow(resultsFile, r, "ANFIS_Hybrid", rmseH, maeH, r2H, tHybrid, "");

        % ---------------- METHOD 2: PSO-ANFIS (hand-rolled PSO, rule-structure) ----------------
        fprintf('  [PSO_ANFIS] starting PSO search (10 particles x 10 iters = 100 evals)...\n'); t0 = tic;
        lb = [0.3, 0.8]; ub = [1.2, 2.0];
        [bestParams, psoTrace] = simplePSO(@(p) ruleStructureFitness(p, Xtr, ytr, Xv, yv), lb, ub, 10, 10);
        fprintf('  [PSO_ANFIS] search done (best fitness=%.4f), now training final model...\n', min(psoTrace));
        optsP = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', bestParams(1), 'SquashFactor', bestParams(2));
        initFisP = genfis(Xtr, ytr, optsP);
        anfisOptP = anfisOptions('InitialFIS', initFisP, 'EpochNumber', cfg.anfisEpochs, ...
            'OptimizationMethod', 0, 'ValidationData', checkData, ...
            'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
        [fisP, ~, ~, chkFisP, chkErrP] = anfis(trainData, anfisOptP);
        fisP_best = chkFisP; if isempty(chkErrP), fisP_best = fisP; end
        tPSO = toc(t0);
        predP = evalfis(fisP_best, Xte);
        [rmseP, maeP, r2P] = computeMetrics(yte, predP);
        fprintf('  [PSO_ANFIS] DONE in %.1fs | RMSE=%.4f MAE=%.4f R2=%.4f | params=[%.3f, %.3f]\n', ...
            tPSO, rmseP, maeP, r2P, bestParams(1), bestParams(2));
        appendRow(resultsFile, r, "PSO_ANFIS", rmseP, maeP, r2P, tPSO, ...
            sprintf("ClusterInfluence=%.3f;SquashFactor=%.3f", bestParams(1), bestParams(2)));

        if r == 1
            % Save first-run FIS pair for MF before/after plotting later
            save(sprintf('quick_fis_%s.mat', outVar), 'initFis', 'fisP_best', 'fisH_best');
        end
    end
    fprintf('\n%s: all %d runs complete. Results in %s\n', outVar, N_RUNS, resultsFile);
end

fprintf('\n\n=== ALL DONE. Summary: ===\n');
for ov = 1:numel(outputVars)
    t = readtable(sprintf('quick_results_%s.csv', outputVars{ov}));
    fprintf('\n--- %s ---\n', outputVars{ov});
    summary_ = groupsummary(t, 'Method', {'mean','std'}, {'RMSE','MAE','R2','TrainTime_s'});
    disp(summary_);
end


%% ================= LOCAL FUNCTIONS =================
function [rmse, mae, r2] = computeMetrics(yActual, yPred)
    yActual = yActual(:); yPred = yPred(:);
    err = yActual - yPred;
    rmse = sqrt(mean(err.^2));
    mae = mean(abs(err));
    ssRes = sum(err.^2); ssTot = sum((yActual-mean(yActual)).^2);
    r2 = 1 - ssRes/ssTot;
end

function appendRow(filename, run, method, rmse, mae, r2, trainTime, paramStr)
    % Appends one row directly to the CSV on disk -- this is what
    % makes partial/interrupted runs still useful.
    newRow = table(run, method, rmse, mae, r2, trainTime, string(paramStr), ...
        'VariableNames', {'Run','Method','RMSE','MAE','R2','TrainTime_s','BestPSOParams_str'});
    existing = readtable(filename);
    combined = [existing; newRow];
    writetable(combined, filename);
end

function rmse = ruleStructureFitness(params, Xtr, ytr, Xv, yv)
    try
        opts = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', params(1), 'SquashFactor', params(2));
        initFis = genfis(Xtr, ytr, opts);
        anfisOpt = anfisOptions('InitialFIS', initFis, 'EpochNumber', 6, 'OptimizationMethod', 0, ...
            'DisplayANFISInformation',0,'DisplayErrorValues',0,'DisplayStepSize',0,'DisplayFinalResults',0);
        fis = anfis([Xtr, ytr], anfisOpt);
        pred = evalfis(fis, Xv);
        rmse = sqrt(mean((yv-pred).^2));
        if ~isfinite(rmse), rmse = 1e6; end
    catch
        rmse = 1e6;
    end
end

function [bestParams, trace] = simplePSO(fitFcn, lb, ub, nParticles, maxIter)
    % Minimal hand-rolled PSO -- no Global Optimization Toolbox
    % dependency. Standard velocity/position update rule.
    dim = numel(lb);
    w = 0.7; c1 = 1.5; c2 = 1.5;
    pos = lb + rand(nParticles, dim) .* (ub - lb);
    vel = zeros(nParticles, dim);
    pbest = pos; pbestFit = arrayfun(@(i) fitFcn(pos(i,:)), 1:nParticles)';
    [gbestFit, gi] = min(pbestFit); gbest = pos(gi,:);
    trace = zeros(1, maxIter);
    fprintf('    PSO iter: ');
    for t = 1:maxIter
        for i = 1:nParticles
            r1 = rand(1,dim); r2 = rand(1,dim);
            vel(i,:) = w*vel(i,:) + c1*r1.*(pbest(i,:)-pos(i,:)) + c2*r2.*(gbest-pos(i,:));
            pos(i,:) = min(max(pos(i,:) + vel(i,:), lb), ub);
        end
        fit = arrayfun(@(i) fitFcn(pos(i,:)), 1:nParticles)';
        improved = fit < pbestFit;
        pbest(improved,:) = pos(improved,:); pbestFit(improved) = fit(improved);
        [currentBest, gi] = min(pbestFit);
        if currentBest < gbestFit, gbestFit = currentBest; gbest = pbest(gi,:); end
        trace(t) = gbestFit;
        fprintf('.');
    end
    fprintf(' done\n');
    bestParams = gbest;
end