%% generalization_test.m
% ================================================================
% GENERALIZATION TESTING -- addresses the reviewer point that the
% paper's "unified framework, no per-crop retraining" novelty claim
% needs a DIRECT test, not just an assertion.
%
% IMPORTANT DISTINCTION (report this explicitly in the paper -- it
% preempts a reviewer catching it themselves, which reads far worse):
%
%   TEST 1 - INTERPOLATION (legitimate generalization claim):
%     SoilType is encoded as 1/2/3 (Sandy/Loamy/Clay), but soil
%     composition is a real physical CONTINUUM -- a field that's
%     "half-sandy, half-loamy" is a meaningful, physically real
%     condition. Querying the trained model at SoilType=1.5 (an
%     intermediate value never seen in training) is a genuine test of
%     whether the fuzzy model has learned a sensible continuous
%     relationship, not just memorized 9 lookup points. This IS
%     evidence for the "generalizes without retraining" claim.
%
%   TEST 2 - EXTRAPOLATION (report as a LIMITATION, not a success):
%     Crop is encoded as 1/2/3 (Groundnut/Maize/Wheat) -- but these
%     are NOMINAL categories with NO ordinal relationship. There is no
%     meaningful sense in which Maize (2) is "between" Groundnut (1)
%     and Wheat (3), so querying the model at CropID=4 for a held-out
%     4th crop (Cowpea) is asking the model to extrapolate along an
%     axis that was never meaningful in the first place. If the
%     result looks reasonable, that's coincidental, not evidence of
%     generalization. Report this honestly: "the current scalar
%     encoding of nominal crop categories does not support principled
%     generalization to unseen crops; one-hot encoding or crop-trait
%     features (e.g. seed diameter, row-spacing class) are proposed
%     as future work to enable this."
% ================================================================

clear; clc;
cfg = config_planter();
load('trained_anfis_models.mat', 'fisDistance', 'fisSeeds');

fprintf('=================================================================\n');
fprintf('TEST 1: INTERPOLATION -- unseen intermediate SOIL condition\n');
fprintf('(legitimate generalization test: soil is a real continuum)\n');
fprintf('=================================================================\n');

% Query at SoilType = 1.5 (halfway between Sandy=1 and Loamy=2), for
% each crop, and sanity-check the output falls BETWEEN the two
% training-seen values (a basic monotonicity/plausibility check).
soilMidpoints = [1.5, 2.5]; % Sandy-Loamy midpoint, Loamy-Clay midpoint
for c = 1:numel(cfg.cropIDs)
    cropName = cfg.cropNames{c};
    fprintf('\n-- %s --\n', cropName);
    d1 = evalfis(fisDistance, [c, 1]); d2 = evalfis(fisDistance, [c, 2]); d3 = evalfis(fisDistance, [c, 3]);
    for sm = soilMidpoints
        dmid = evalfis(fisDistance, [c, sm]);
        smid = evalfis(fisSeeds, [c, sm]);
        lower = min([d1 d2 d3]); upper = max([d1 d2 d3]);
        plausible = (dmid >= lower - 1) && (dmid <= upper + 1); % small tolerance
        fprintf('  SoilType=%.1f -> Distance=%.2fcm (plausible range [%.1f, %.1f]: %s), Seeds=%.2f\n', ...
            sm, dmid, lower, upper, string(plausible), smid);
    end
end

fprintf('\n=================================================================\n');
fprintf('TEST 2: EXTRAPOLATION -- unseen 4th CROP (reported as limitation)\n');
fprintf('=================================================================\n');

% Cowpea baseline (illustrative literature-typical value, NOT used in
% training) -- cite an actual agronomic source for this in the paper
% rather than treating this placeholder number as validated.
cowpeaTrueDistance = 20.0; % cm, illustrative
cowpeaTrueSeeds = 1;       % typical single-seed hole for cowpea

for soilID = 1:3
    predD = evalfis(fisDistance, [4, soilID]); % CropID=4 = extrapolation
    predS = evalfis(fisSeeds, [4, soilID]);
    gapD = predD - cowpeaTrueDistance;
    gapS = predS - cowpeaTrueSeeds;
    fprintf('Soil=%s: predicted Distance=%.2fcm (true~%.1fcm, gap=%.2f) | predicted Seeds=%.2f (true=%d, gap=%.2f)\n', ...
        cfg.soilNames{soilID}, predD, cowpeaTrueDistance, gapD, predS, cowpeaTrueSeeds, gapS);
end
fprintf('\nThese Test 2 numbers should be reported as a LIMITATION demonstration,\n');
fprintf('not a generalization success -- the gap size mainly reflects where\n');
fprintf('CropID=4 happens to sit relative to the learned membership functions,\n');
fprintf('not genuine crop-trait understanding.\n');

%% ================= SAVE FOR GENERALIZATION BAR CHART =================
genTable = table();
genTable.Type(1) = "Groundnut (trained)"; genTable.TrainedOn(1) = true;
genTable.Type(2) = "Maize (trained)"; genTable.TrainedOn(2) = true;
genTable.Type(3) = "Wheat (trained)"; genTable.TrainedOn(3) = true;
genTable.Type(4) = "Cowpea (unseen, extrapolation)"; genTable.TrainedOn(4) = false;

% RMSE for trained crops: use test-set RMSE already available from
% full_comparison_results.mat if present; otherwise approximate from
% the trained model directly against its own training distribution.
try
    load('full_comparison_results.mat', 'allResults');
    genTable.RMSE(1:3) = mean(allResults.Distance_cm.PSO_ANFIS_Proposed.rmse, 'omitnan');
catch
    genTable.RMSE(1:3) = NaN; % run full_comparison.m first if this is NaN
end
genTable.RMSE(4) = abs(evalfis(fisDistance, [4,2]) - cowpeaTrueDistance); % Loamy soil, illustrative
writetable(genTable, 'table3_generalization.csv');
fprintf('\nSaved table3_generalization.csv\n');