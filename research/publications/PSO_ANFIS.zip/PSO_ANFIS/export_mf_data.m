%% export_mf_data.m -- exports MF parameters as CSV, no graphics involved at all
% This sidesteps MATLAB's broken graphics/display pipeline entirely --
% no figure, no print, no saveas. Just raw numbers out to CSV, which I
% can plot reliably on my end.

load('quick_fis_Distance_cm.mat', 'initFis', 'fisP_best');

exportMFs(initFis, 'mf_before_pso.csv');
exportMFs(fisP_best, 'mf_after_pso.csv');
fprintf('Saved mf_before_pso.csv and mf_after_pso.csv -- paste their contents back.\n');

function exportMFs(fis, filename)
T = table();
row = 1;
for i = 1:numel(fis.Inputs)
    inputName = fis.Inputs(i).Name;
    for j = 1:numel(fis.Inputs(i).MembershipFunctions)
        mf = fis.Inputs(i).MembershipFunctions(j);
        T.InputIndex(row) = i;
        T.InputName(row) = string(inputName);
        T.MFIndex(row) = j;
        T.MFName(row) = string(mf.Name);
        T.MFType(row) = string(mf.Type);
        % Gaussian MFs (gaussmf) have Parameters = [sigma, center]
        % Other MF types have different parameter counts -- pad/label generically
        params = mf.Parameters;
        for p = 1:numel(params)
            T.(sprintf('Param%d', p))(row) = params(p);
        end
        row = row + 1;
    end
end
writetable(T, filename);
end