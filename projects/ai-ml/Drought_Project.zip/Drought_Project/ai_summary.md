# AI Context Summary — GRACE TWS Drought Forecasting (synthetic demo)

> Feed this file to another AI/LLM instead of the raw dataset for fast, 
> grounded reasoning about this competition.

## Dataset
- Rows: 2700, Columns: 19
- Data quality score: 100.0/100
- Columns with most missing data: ['latitude', 'longitude', 'date', 'TWS_t', 'SOIL_MOISTURE_t', 'SPEI_01', 'SPEI_02', 'SPEI_03', 'SPEI_04', 'SPEI_05']

## Target
- Mean: 0.05575391181508902, Std: 4.31827058836814, Range: [-10.78208920822726, 10.9013243996099]
- Outliers (IQR method): 0.0% of rows

## Leakage flags raised
['suspicious_correlations']

## Most unstable (train/test drifted) features
['SPEI_02', 'SPEI_06', 'TWS_t', 'leaky_feature', 'SPEI_11', 'SPEI_04', 'SPEI_07', 'SPEI_01', 'SPEI_05', 'SPEI_03']

## Top features by mutual information with target
['leaky_feature', 'TWS_t', 'SOIL_MOISTURE_t', 'SPEI_07', 'SPEI_11', 'SPEI_10', 'SPEI_01', 'SPEI_09', 'SPEI_03', 'SPEI_04']

## Recommended validation strategy
- **Spatio-Temporal Blocked CV** (priority 1): Hold out entire time blocks (e.g. last 3-6 months) AND a spatial subset of locations simultaneously, so folds never share (place, time) adjacency with training data. This best mimics the true test regime: predicting t+1 at locations/times not seen during training.
- **Walk-Forward (Rolling Origin) CV** (priority 2): Train on months [1..k], validate on month k+1, then slide the window forward. Repeat across multiple origins and average scores. This directly matches the competition's one-month-ahead prediction task and is essential since GRACE TWS is a genuine time series with autocorrelation.
- **Spatial CV (leave-region-out)** (priority 3): Group locations into spatial blocks (e.g. 5-degree grid cells or climate zones) and hold whole blocks out, to test generalisation to unseen geography and guard against spatial autocorrelation inflating scores.

## Recommended feature engineering directions
['Lag Features', 'Rolling Windows', 'Cyclic Encoding', 'Trend Features', 'Spatial Neighbor Features', 'Region Aggregations', 'Hydrological / Climate Features', 'Interaction Features', 'Anomaly Features']

## Strategic recommendation
- Best model families: ['LinearRegression', 'Ridge', 'ExtraTrees']
- Ensemble approach: Blend/stack the top baseline models (LinearRegression, Ridge, ExtraTrees) — gradient-boosted trees (LightGBM/CatBoost/XGBoost) typically dominate tabular spatio-temporal competitions and are complementary enough to ensemble profitably; a simple weighted average or a linear/Ridge meta-learner on out-of-fold predictions is a strong, low-risk starting point before attempting a full stack.
- Expected leaderboard gains, in priority order:
  - Persistence-delta modelling (predicting the change from TWS_t rather than the raw t+1 value) typically gives the single largest jump over naive regression on raw TWS, since GRACE TWS changes slowly month-to-month.
  - Multi-timescale SPEI features and rolling/lag TWS windows are usually the next largest gains, capturing drought accumulation/recovery dynamics.
  - Spatial neighbour and region-aggregation features typically add smaller but consistent gains by injecting regional context missing from single-cell features.
  - A well-validated ensemble of 2-3 boosted-tree models generally adds a further modest but reliable improvement over the single best model.