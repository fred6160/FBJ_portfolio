# Feature Engineering Recommendations

_Generated 2026-08-01 19:01 by Competition Intelligence Generator_

## Lag Features
Create lagged values of TWS_t and SOIL_MOISTURE_t (t-1, t-2, t-3, t-6, t-12) per (lat, lon) location, sorted by date, using groupby+shift.

```python
df = df.sort_values(['lat','lon','date'])
for lag in [1,2,3,6,12]:
    df[f'TWS_t_lag{lag}'] = df.groupby(['lat','lon'])['TWS_t'].shift(lag)
```

## Rolling Windows
Rolling mean/std/min/max of TWS_t and SOIL_MOISTURE_t over 3, 6, and 12-month windows per location, to capture drought accumulation trends.

```python
df['TWS_roll_mean_6'] = df.groupby(['lat','lon'])['TWS_t']\
    .transform(lambda s: s.rolling(6, min_periods=1).mean())
```

## Cyclic Encoding
Encode calendar month as sin/cos pairs to represent seasonality without an artificial discontinuity between December and January.

```python
df['month'] = pd.to_datetime(df['date']).dt.month
df['month_sin'] = np.sin(2*np.pi*df['month']/12)
df['month_cos'] = np.cos(2*np.pi*df['month']/12)
```

## Trend Features
Slope of TWS_t over the trailing 3/6/12 months per location (simple linear regression slope) as a directly interpretable drought-trend signal.

```python
def slope(s):
    x = np.arange(len(s))
    return np.polyfit(x, s, 1)[0] if len(s) > 1 else np.nan
df['TWS_trend_6'] = df.groupby(['lat','lon'])['TWS_t']\
    .transform(lambda s: s.rolling(6).apply(slope, raw=True))
```

## Spatial Neighbor Features
For each grid cell, compute the mean TWS_t of its k-nearest neighbouring cells (e.g. via a BallTree on lat/lon) to inject regional hydrological context.

```python
from sklearn.neighbors import BallTree
coords = np.radians(df[['lat','lon']].drop_duplicates().values)
tree = BallTree(coords, metric='haversine')
```

## Region Aggregations
Aggregate features by coarse spatial bins (e.g. 5-degree lat/lon grid cells or named climate zone) to give the model region-level baselines to deviate from.

```python
df['grid_lat'] = (df['lat'] // 5) * 5
df['grid_lon'] = (df['lon'] // 5) * 5
df['region_TWS_mean'] = df.groupby(['grid_lat','grid_lon','date'])['TWS_t'].transform('mean')
```

## Hydrological / Climate Features
Combine SPEI timescales (SPEI_01, SPEI_02, SPEI_03, SPEI_04, SPEI_05, SPEI_06...) into a composite drought severity index (e.g. weighted average favouring shorter timescales for near-term signal), and compute rate-of-change between adjacent SPEI timescales.

```python
df['SPEI_composite'] = df[['SPEI_01','SPEI_03','SPEI_06']].mean(axis=1)
df['SPEI_delta_1_3'] = df['SPEI_01'] - df['SPEI_03']
```

## Interaction Features
Interaction / ratio terms between soil moisture and TWS (e.g. SOIL_MOISTURE_t / TWS_t, or their product) since depleted soil moisture combined with low TWS is a stronger drought signal than either alone.

```python
df['soil_tws_ratio'] = df['SOIL_MOISTURE_t'] / (df['TWS_t'].abs() + 1e-3)
```

## Anomaly Features
Deviation of TWS_t from that location's own long-run historical mean/std (a location-specific z-score) — this normalises for baseline water storage differences across geography, which raw TWS values conflate.

```python
loc_stats = df.groupby(['lat','lon'])['TWS_t'].transform(['mean','std'])
df['TWS_zscore'] = (df['TWS_t'] - loc_stats['mean']) / (loc_stats['std'] + 1e-6)
```

