# Final Competition Strategy

_Generated 2026-08-01 19:01 by Competition Intelligence Generator_

## Best model families
LinearRegression, Ridge, ExtraTrees

## Ensembling
Blend/stack the top baseline models (LinearRegression, Ridge, ExtraTrees) — gradient-boosted trees (LightGBM/CatBoost/XGBoost) typically dominate tabular spatio-temporal competitions and are complementary enough to ensemble profitably; a simple weighted average or a linear/Ridge meta-learner on out-of-fold predictions is a strong, low-risk starting point before attempting a full stack.

## Validation
- **Spatio-Temporal Blocked CV**: Hold out entire time blocks (e.g. last 3-6 months) AND a spatial subset of locations simultaneously, so folds never share (place, time) adjacency with training data. This best mimics the true test regime: predicting t+1 at locations/times not seen during training.
- **Walk-Forward (Rolling Origin) CV**: Train on months [1..k], validate on month k+1, then slide the window forward. Repeat across multiple origins and average scores. This directly matches the competition's one-month-ahead prediction task and is essential since GRACE TWS is a genuine time series with autocorrelation.
- **Spatial CV (leave-region-out)**: Group locations into spatial blocks (e.g. 5-degree grid cells or climate zones) and hold whole blocks out, to test generalisation to unseen geography and guard against spatial autocorrelation inflating scores.

## Preprocessing
- Impute missing SPEI/soil-moisture values with location-specific (not global) medians or forward-fill within each location's time series, since drought indices are strongly spatially and temporally autocorrelated.
- Standardise/scale features per climate zone or grid cell if using linear/neural models; tree-based models (the likely leaderboard leaders) need no scaling.
- The most unstable features between train/test are ['SPEI_02', 'SPEI_06', 'TWS_t', 'leaky_feature', 'SPEI_11', 'SPEI_04', 'SPEI_07', 'SPEI_01'] — consider dropping, re-deriving as deltas/ratios, or applying distribution-alignment techniques for these before trusting them heavily.

## Expected weaknesses to plan around
- Baseline linear models will likely underperform due to nonlinear drought dynamics and spatial heterogeneity — expect them to serve mainly as a sanity-check floor.
- Tree-based models can struggle to extrapolate to TWS extremes not seen in training (e.g. unprecedented drought severity); consider monotonic constraints or residual-on-persistence modelling (predict the change TWS_t+1 - TWS_t rather than the absolute value) to improve extrapolation.
- Random or naive splits will overstate true generalisation given strong spatio-temporal autocorrelation — see validation strategy for the fix.

## Expected leaderboard improvements, in priority order
1. Persistence-delta modelling (predicting the change from TWS_t rather than the raw t+1 value) typically gives the single largest jump over naive regression on raw TWS, since GRACE TWS changes slowly month-to-month.
2. Multi-timescale SPEI features and rolling/lag TWS windows are usually the next largest gains, capturing drought accumulation/recovery dynamics.
3. Spatial neighbour and region-aggregation features typically add smaller but consistent gains by injecting regional context missing from single-cell features.
4. A well-validated ensemble of 2-3 boosted-tree models generally adds a further modest but reliable improvement over the single best model.

## ⚠️ Resolve first
['suspicious_correlations']
