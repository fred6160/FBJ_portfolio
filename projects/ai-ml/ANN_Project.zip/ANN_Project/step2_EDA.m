%% ============================================================
%  STEP 2 — EXPLORATORY DATA ANALYSIS (EDA)
%  File: step2_EDA.m
% ============================================================
fprintf('[STEP 2] Performing Exploratory Data Analysis...\n');

load('workspace_step1.mat');

outputLabels = {'BM Midspan (kN·m)', 'BM Support (kN·m)', ...
                'Shear Force (kN)',   'Deflection (mm)', ...
                'Axial Stress (MPa)', 'Shear Stress (MPa)'};

inputLabels  = {'Struct Type','Span (m)','No. Spans','Settlement (mm)', ...
                'Settle Loc','Settle Type','Temp (°C)','Temp Type', ...
                'Soil Type','Subgrade Mod','Load Combo'};

structCodes  = {'2-Span Beam','3-Span Beam','Portal Frame','Multi-bay Frame'};
soilCodes    = {'Clay (Exp.)','Sandy Clay','Laterite','Dense Sand'};

%% 2.1 — Descriptive statistics table ────────────────────────────────────────
fprintf('\n         --- OUTPUT VARIABLE STATISTICS ---\n');
fprintf('         %-26s %8s %8s %8s %8s %8s\n', ...
        'Variable','Min','Mean','Max','Std','CV(%)');
fprintf('         %s\n', repmat('-',1,70));
for i = 1:nOutputs
    col  = Y_raw(:,i);
    cv   = (std(col)/mean(col))*100;
    fprintf('         %-26s %8.2f %8.2f %8.2f %8.2f %7.1f%%\n', ...
            outputLabels{i}, min(col), mean(col), max(col), std(col), cv);
end
fprintf('\n');

%% 2.2 — Figure 1: Input feature distributions ───────────────────────────────
fig1 = figure('Name','EDA - Input Distributions','NumberTitle','off', ...
              'Position',[50 50 1400 700]);
for i = 1:nInputs
    subplot(3,4,i);
    histogram(X_raw(:,i), 20, 'FaceColor',[0.2 0.45 0.7], ...
              'EdgeColor','white','FaceAlpha',0.85);
    title(inputLabels{i}, 'FontSize',9, 'FontWeight','bold');
    xlabel('Value','FontSize',8);
    ylabel('Count','FontSize',8);
    grid on; box off;
    set(gca,'FontSize',8);
end
sgtitle('Distribution of ANN Input Features', 'FontSize',13,'FontWeight','bold');
saveas(fig1, 'Fig1_Input_Distributions.png');

%% 2.3 — Figure 2: Output variable distributions ────────────────────────────
fig2 = figure('Name','EDA - Output Distributions','NumberTitle','off', ...
              'Position',[50 50 1200 600]);
colors = [0.84 0.19 0.15; 0.20 0.63 0.17; 0.12 0.47 0.71;
          0.89 0.55 0.00; 0.58 0.24 0.55; 0.50 0.50 0.50];
for i = 1:nOutputs
    subplot(2,3,i);
    histogram(Y_raw(:,i), 25, 'FaceColor', colors(i,:), ...
              'EdgeColor','white','FaceAlpha',0.85);
    title(outputLabels{i},'FontSize',10,'FontWeight','bold');
    xlabel('Value','FontSize',9);
    ylabel('Frequency','FontSize',9);
    grid on; box off;
    xline(mean(Y_raw(:,i)),'r--','LineWidth',1.5,'Label','Mean');
end
sgtitle('Distribution of ANN Output (Target) Variables','FontSize',13,'FontWeight','bold');
saveas(fig2,'Fig2_Output_Distributions.png');

%% 2.4 — Figure 3: Correlation heatmap (inputs vs outputs) ──────────────────
fig3 = figure('Name','Correlation Heatmap','NumberTitle','off',...
              'Position',[100 100 900 600]);
allData   = [X_raw, Y_raw];
corrMat   = corr(allData);
% Show only input–output cross-correlations
crossCorr = corrMat(1:nInputs, nInputs+1:end);

imagesc(crossCorr);
colormap(redblue_colormap());
colorbar;
caxis([-1 1]);
set(gca,'XTick',1:nOutputs,  'XTickLabel', outputLabels, 'XTickLabelRotation',30, 'FontSize',9);
set(gca,'YTick',1:nInputs,   'YTickLabel', inputLabels,  'FontSize',9);
title('Pearson Correlation: Inputs vs Outputs','FontSize',12,'FontWeight','bold');

% Annotate values
for r = 1:nInputs
    for c = 1:nOutputs
        val = crossCorr(r,c);
        textColor = 'white';
        if abs(val) < 0.35; textColor = 'black'; end
        text(c, r, sprintf('%.2f',val), 'HorizontalAlignment','center', ...
             'VerticalAlignment','middle','FontSize',7,'Color',textColor,'FontWeight','bold');
    end
end
saveas(fig3,'Fig3_Correlation_Heatmap.png');

%% 2.5 — Figure 4: Settlement effect on BM (by structure type) ──────────────
fig4 = figure('Name','Settlement vs BM by Structure Type','NumberTitle','off',...
              'Position',[100 100 1100 500]);
subplot(1,2,1);
hold on;
mkrs = {'o','s','^','d'};
cmap4 = lines(4);
for st = 1:4
    mask = X_raw(:,1) == st;
    scatter(X_raw(mask,4), Y_raw(mask,1), 20, cmap4(st,:), ...
            mkrs{st}, 'filled','MarkerFaceAlpha',0.6);
end
hold off;
xlabel('Settlement Magnitude (mm)','FontSize',10);
ylabel('Max BM — Midspan (kN·m)','FontSize',10);
title('Settlement vs Midspan BM','FontSize',11,'FontWeight','bold');
legend(structCodes,'Location','northwest','FontSize',8);
grid on; box off;

subplot(1,2,2);
hold on;
for st = 1:4
    mask = X_raw(:,1) == st;
    scatter(X_raw(mask,4), abs(Y_raw(mask,2)), 20, cmap4(st,:), ...
            mkrs{st},'filled','MarkerFaceAlpha',0.6);
end
hold off;
xlabel('Settlement Magnitude (mm)','FontSize',10);
ylabel('|Max BM — Support| (kN·m)','FontSize',10);
title('Settlement vs Support BM','FontSize',11,'FontWeight','bold');
legend(structCodes,'Location','northwest','FontSize',8);
grid on; box off;

sgtitle('Effect of Support Settlement on Bending Moments','FontSize',12,'FontWeight','bold');
saveas(fig4,'Fig4_Settlement_vs_BM.png');

%% 2.6 — Figure 5: Temperature effect on deflection by soil type ─────────────
fig5 = figure('Name','Temperature vs Deflection','NumberTitle','off',...
              'Position',[100 100 1000 480]);
subplot(1,2,1);
hold on;
soilColors = [0.84 0.19 0.15; 0.20 0.63 0.17; 0.12 0.47 0.71; 0.89 0.55 0.00];
for s = 1:4
    mask = X_raw(:,9) == s;
    scatter(X_raw(mask,7), Y_raw(mask,4), 20, soilColors(s,:),'filled','MarkerFaceAlpha',0.6);
end
hold off;
xlabel('Temperature (°C)','FontSize',10);
ylabel('Max Deflection (mm)','FontSize',10);
title('Temperature vs Deflection by Soil Type','FontSize',11,'FontWeight','bold');
legend(soilCodes,'Location','northwest','FontSize',8);
grid on; box off;

subplot(1,2,2);
hold on;
for s = 1:4
    mask = X_raw(:,9) == s;
    scatter(X_raw(mask,7), Y_raw(mask,5), 20, soilColors(s,:),'filled','MarkerFaceAlpha',0.6);
end
hold off;
xlabel('Temperature (°C)','FontSize',10);
ylabel('Axial Stress (MPa)','FontSize',10);
title('Temperature vs Axial Stress by Soil Type','FontSize',11,'FontWeight','bold');
legend(soilCodes,'Location','northwest','FontSize',8);
grid on; box off;

sgtitle('Climate Effects on Structural Response (Nigerian Hot-Climate)','FontSize',12,'FontWeight','bold');
saveas(fig5,'Fig5_Temperature_Effects.png');

%% 2.7 — Figure 6: Boxplot — deflection by structure type ───────────────────
fig6 = figure('Name','Deflection Boxplot','NumberTitle','off',...
              'Position',[100 100 900 500]);
subplot(1,2,1);
grp1 = X_raw(:,1);  % structure type code
boxplot(Y_raw(:,4), grp1, 'Labels', structCodes, 'Colors', cmap4);
ylabel('Max Deflection (mm)','FontSize',10);
title('Deflection by Structure Type','FontSize',11,'FontWeight','bold');
grid on; box off;

subplot(1,2,2);
grp2 = X_raw(:,9);  % soil type code
boxplot(Y_raw(:,4), grp2, 'Labels', soilCodes, 'Colors', soilColors);
ylabel('Max Deflection (mm)','FontSize',10);
title('Deflection by Soil Type','FontSize',11,'FontWeight','bold');
grid on; box off;

sgtitle('Deflection Distribution by Category','FontSize',12,'FontWeight','bold');
saveas(fig6,'Fig6_Deflection_Boxplots.png');

fprintf('[STEP 2] EDA complete. Figures 1–6 saved.\n\n');

%% ── Helper: Red-Blue colormap ─────────────────────────────────────────────
function cmap = redblue_colormap()
    n = 64;
    r = [linspace(0.7,1,n/2), linspace(1,0.2,n/2)]';
    g = [linspace(0.7,1,n/2), linspace(1,0.2,n/2)]';
    b = [linspace(1,1,n/2),   linspace(1,0.2,n/2)]';
    r2= [linspace(0.2,1,n/2), linspace(1,0.7,n/2)]';
    b2= [linspace(1,1,n/2),   linspace(1,0.7,n/2)]';
    cmap = [r2, g, b];
    % simpler: use built-in or manual RdBu
    top    = [linspace(0.7,1,32)', linspace(0.7,1,32)', ones(32,1)];
    bottom = [ones(32,1), linspace(1,0.7,32)', linspace(1,0.7,32)'];
    cmap   = [top; flipud(bottom)];
end
