%% ============================================================
%  STEP 1 — DATA LOADING & PRE-PROCESSING
%  File: step1_load_preprocess.m
% ============================================================
fprintf('[STEP 1] Loading and pre-processing dataset...\n');

%% 1.1 — Import CSV ─────────────────────────────────────────────────────────
dataFile = 'ANN_Full_Dataset.csv';
if ~isfile(dataFile)
    error('Dataset file "%s" not found. Place it in the MATLAB working directory.', dataFile);
end

rawTable = readtable(dataFile, 'VariableNamingRule', 'preserve');
fprintf('         Loaded %d rows × %d columns\n', height(rawTable), width(rawTable));

%% 1.2 — Select numeric input features (columns) ────────────────────────────
%
%  INPUT FEATURES (9 numeric inputs for the ANN):
%  ┌─────┬──────────────────────────────────────┬─────────────────────────┐
%  │  #  │  Column Name                         │  Range / Type           │
%  ├─────┼──────────────────────────────────────┼─────────────────────────┤
%  │  1  │  Structure Type Code                 │  1–4 (integer code)     │
%  │  2  │  Span Length (m)                     │  4–8 m                  │
%  │  3  │  No. of Spans                        │  2–3                    │
%  │  4  │  Settlement Magnitude (mm)           │  0–50 mm                │
%  │  5  │  Settlement Location Code            │  0–4                    │
%  │  6  │  Settlement Type Code                │  0–2                    │
%  │  7  │  Temperature (°C)                    │  25–55 °C               │
%  │  8  │  Temp Load Type Code                 │  1–2                    │
%  │  9  │  Soil Type Code                      │  1–4                    │
%  │ 10  │  Subgrade Modulus (kN/m³)            │  12000–50000            │
%  │ 11  │  Load Combo Code                     │  1–3                    │
%  └─────┴──────────────────────────────────────┴─────────────────────────┘
%
%  OUTPUT TARGETS (6 structural response variables):
%  ┌─────┬──────────────────────────────────────┬─────────────────────────┐
%  │  1  │  Max BM — Midspan (kN·m)             │  Sagging moment         │
%  │  2  │  Max BM — Support (kN·m)             │  Hogging moment         │
%  │  3  │  Max Shear Force (kN)                │  Critical shear         │
%  │  4  │  Max Deflection — Midspan (mm)       │  Serviceability check   │
%  │  5  │  Axial Stress (MPa)                  │  Extreme fibre stress   │
%  │  6  │  Shear Stress (MPa)                  │  Average shear stress   │
%  └─────┴──────────────────────────────────────┴─────────────────────────┘

inputCols  = {'Structure Type Code', 'Span Length (m)', 'No. of Spans', ...
              'Settlement Magnitude (mm)', 'Settlement Location Code', ...
              'Settlement Type Code', 'Temperature (?C)', ...
              'Temp Load Type Code', 'Soil Type Code', ...
              'Subgrade Modulus (kN/m?)', 'Load Combo Code'};

outputCols = {'Max BM ? Midspan (kN?m)', 'Max BM ? Support (kN?m)', ...
              'Max Shear Force (kN)', 'Max Deflection ? Midspan (mm)', ...
              'Axial Stress (MPa)', 'Shear Stress (MPa)'};

% Robust column matching (handles encoding quirks in special characters)
allCols = rawTable.Properties.VariableNames;
findCol = @(keyword) find(contains(allCols, keyword, 'IgnoreCase', true), 1);

inputIdx = [ findCol('Structure Type Code'), ...
             findCol('Span Length'),         ...
             findCol('No. of Spans'),        ...
             findCol('Settlement Magnitude'),  ...
             findCol('Settlement Location Code'), ...
             findCol('Settlement Type Code'), ...
             findCol('Temperature'),          ...
             findCol('Temp Load Type Code'),  ...
             findCol('Soil Type Code'),       ...
             findCol('Subgrade Modulus'),     ...
             findCol('Load Combo Code')       ];

outputIdx = [ findCol('Midspan'),        ...   % BM midspan
              findCol('Support (kN'),    ...   % BM support
              findCol('Shear Force'),    ...   % Shear force
              findCol('Deflection'),     ...   % Deflection
              findCol('Axial Stress'),   ...   % Axial stress
              findCol('Shear Stress')    ];    % Shear stress

% Remove any duplicates from fuzzy matching
inputIdx  = unique(inputIdx,  'stable');
outputIdx = unique(outputIdx, 'stable');

X_raw = table2array(rawTable(:, inputIdx));   % [N × 11]
Y_raw = table2array(rawTable(:, outputIdx));  % [N × 6]

nSamples  = size(X_raw, 1);
nInputs   = size(X_raw, 2);
nOutputs  = size(Y_raw, 2);

fprintf('         Inputs:  %d features\n', nInputs);
fprintf('         Outputs: %d targets\n',  nOutputs);
fprintf('         Samples: %d rows\n',     nSamples);

%% 1.3 — Data quality checks ─────────────────────────────────────────────────
nanRows_X = any(isnan(X_raw), 2);
nanRows_Y = any(isnan(Y_raw), 2);
badRows   = nanRows_X | nanRows_Y;

if sum(badRows) > 0
    fprintf('         WARNING: Removing %d rows with NaN values.\n', sum(badRows));
    X_raw = X_raw(~badRows, :);
    Y_raw = Y_raw(~badRows, :);
end

% Remove outliers using 3-sigma rule on outputs
mu_Y  = mean(Y_raw);
sig_Y = std(Y_raw);
outMask = any(abs(Y_raw - mu_Y) > 4 * sig_Y, 2);
if sum(outMask) > 0
    fprintf('         Removing %d statistical outliers (4-sigma rule).\n', sum(outMask));
    X_raw = X_raw(~outMask, :);
    Y_raw = Y_raw(~outMask, :);
end

nSamples = size(X_raw, 1);
fprintf('         Clean dataset: %d rows\n', nSamples);

%% 1.4 — Normalisation (mapminmax: scale to [-1, +1]) ──────────────────────
%  IMPORTANT: ps_X and ps_Y are saved and MUST be used when making predictions
%  with new data — denormalise outputs using ps_Y before interpreting results.

[X_norm, ps_X] = mapminmax(X_raw');   % MATLAB convention: features × samples
[Y_norm, ps_Y] = mapminmax(Y_raw');

%  Transpose back to samples × features for splitting
X_norm = X_norm';
Y_norm = Y_norm';

%% 1.5 — Train / Validation / Test split (70 / 15 / 15) ────────────────────
rng(42);   % fixed seed for reproducibility
idx      = randperm(nSamples);
nTrain   = round(0.70 * nSamples);
nVal     = round(0.15 * nSamples);
% nTest  = remainder

trainIdx = idx(1 : nTrain);
valIdx   = idx(nTrain+1 : nTrain+nVal);
testIdx  = idx(nTrain+nVal+1 : end);

X_train = X_norm(trainIdx, :);   Y_train = Y_norm(trainIdx, :);
X_val   = X_norm(valIdx,   :);   Y_val   = Y_norm(valIdx,   :);
X_test  = X_norm(testIdx,  :);   Y_test  = Y_norm(testIdx,  :);

fprintf('         Split — Train: %d | Val: %d | Test: %d\n', ...
        numel(trainIdx), numel(valIdx), numel(testIdx));

%% 1.6 — Save workspace variables for downstream scripts ───────────────────
save('workspace_step1.mat', ...
     'X_raw','Y_raw','X_norm','Y_norm', ...
     'X_train','Y_train','X_val','Y_val','X_test','Y_test', ...
     'ps_X','ps_Y', ...
     'trainIdx','valIdx','testIdx', ...
     'nSamples','nInputs','nOutputs', ...
     'rawTable','inputIdx','outputIdx');

fprintf('[STEP 1] COMPLETE.\n\n');
