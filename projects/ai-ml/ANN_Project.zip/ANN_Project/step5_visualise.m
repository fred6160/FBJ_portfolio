%% ============================================================
%  STEP 5 — ADVANCED VISUALISATIONS
%  File: step5_visualise.m
%
%  Generates publication-quality figures:
%    Fig 12 — Response surface: Settlement vs Temperature → BM
%    Fig 13 — Sensitivity analysis (input importance)
%    Fig 14 — 3D surface: Span × Settlement → Deflection
%    Fig 15 — Structural response envelopes by structure type
%    Fig 16 — Soil type influence on settlement-induced BM
%    Fig 17 — Nigerian climate: temperature effect comparison
% ============================================================
fprintf('[STEP 5] Generating visualisations...\n');

load('workspace_step1.mat');
load('workspace_step3.mat');
load('workspace_step4.mat');

structLabels = {'2-Span Beam','3-Span Beam','Portal Frame','Multi-bay Frame'};
soilLabels   = {'Clay (Exp.)','Sandy Clay','Laterite','Dense Sand'};

%% 5.1 — Figure 12: Response surface Settlement × Temperature → BM Midspan ──
fig12 = figure('Name','Response Surface BM','NumberTitle','off','Position',[50 50 1100 480]);

deltaRange = linspace(0, 50, 40);
tempRange  = linspace(25, 55, 40);
[DG, TG]   = meshgrid(deltaRange, tempRange);

% Fix other inputs at their median values
X_median = median(X_raw);   % 1×11

subplot(1,2,1);
BM_surf = zeros(size(DG));
for r = 1:size(DG,1)
    for c = 1:size(DG,2)
        x_in            = X_median;
        x_in(4)         = DG(r,c);   % settlement
        x_in(7)         = TG(r,c);   % temperature
        x_in_n          = mapminmax('apply', x_in', ps_X);
        y_out_n         = net_best(x_in_n);
        y_out           = mapminmax('reverse', y_out_n, ps_Y);
        BM_surf(r,c)    = y_out(1);  % BM midspan
    end
end
surf(DG, TG, BM_surf, 'EdgeAlpha', 0.2, 'FaceAlpha', 0.9);
colormap(jet); colorbar;
xlabel('Settlement (mm)','FontSize',10); ylabel('Temperature (°C)','FontSize',10);
zlabel('BM Midspan (kN·m)','FontSize',10);
title('Response Surface: BM Midspan','FontSize',11,'FontWeight','bold');
view(45, 30); grid on;

subplot(1,2,2);
DEFL_surf = zeros(size(DG));
for r = 1:size(DG,1)
    for c = 1:size(DG,2)
        x_in            = X_median;
        x_in(4)         = DG(r,c);
        x_in(7)         = TG(r,c);
        x_in_n          = mapminmax('apply', x_in', ps_X);
        y_out_n         = net_best(x_in_n);
        y_out           = mapminmax('reverse', y_out_n, ps_Y);
        DEFL_surf(r,c)  = y_out(4);  % deflection
    end
end
surf(DG, TG, DEFL_surf, 'EdgeAlpha', 0.2, 'FaceAlpha', 0.9);
colormap(jet); colorbar;
xlabel('Settlement (mm)','FontSize',10); ylabel('Temperature (°C)','FontSize',10);
zlabel('Deflection (mm)','FontSize',10);
title('Response Surface: Midspan Deflection','FontSize',11,'FontWeight','bold');
view(45, 30); grid on;

sgtitle('ANN Response Surfaces — Settlement × Temperature Interaction', ...
        'FontSize',12,'FontWeight','bold');
saveas(fig12,'Fig12_Response_Surfaces.png');

%% 5.2 — Figure 13: Sensitivity analysis (feature importance) ────────────────
%  Method: Perturb each input ±10%, compute change in each output → importance
fprintf('         Computing sensitivity analysis...\n');

inputLabels = {'Struct Type','Span (m)','No. Spans','Settlement (mm)', ...
               'Settle Loc','Settle Type','Temp (°C)','Temp Type', ...
               'Soil Type','Subgrade Mod','Load Combo'};

X_base_n = mapminmax('apply', median(X_raw)', ps_X);
Y_base_n = net_best(X_base_n);

sensitivity = zeros(nInputs, nOutputs);
perturb     = 0.15;   % ±15% perturbation

for i = 1:nInputs
    X_up  = X_base_n; X_up(i)   = X_up(i) * (1 + perturb);
    X_dn  = X_base_n; X_dn(i)   = X_dn(i) * (1 - perturb);
    Y_up  = net_best(X_up);
    Y_dn  = net_best(X_dn);
    sensitivity(i,:) = mean(abs(Y_up - Y_dn) ./ (abs(Y_base_n) + 1e-10), 2)';
end
sens_importance = mean(sensitivity, 2);   % average across all outputs

fig13 = figure('Name','Sensitivity Analysis','NumberTitle','off','Position',[50 50 1200 500]);
subplot(1,2,1);
[sorted_imp, sort_idx] = sort(sens_importance, 'descend');
barh(sorted_imp, 'FaceColor',[0.2 0.47 0.71],'EdgeColor','white');
set(gca,'YTickLabel', inputLabels(sort_idx), 'YDir','reverse','FontSize',10);
xlabel('Mean Sensitivity Index','FontSize',11);
title('Input Feature Importance','FontSize',12,'FontWeight','bold');
grid on; box off;

subplot(1,2,2);
imagesc(sensitivity');
colormap(hot); colorbar;
set(gca,'XTick',1:nInputs, 'XTickLabel', inputLabels, 'XTickLabelRotation',40, 'FontSize',8);
set(gca,'YTick',1:nOutputs,'YTickLabel', outputLabels, 'FontSize',8);
title('Sensitivity Heatmap: Input → Output','FontSize',11,'FontWeight','bold');
for r=1:nOutputs
    for c=1:nInputs
        text(c,r,sprintf('%.3f',sensitivity(c,r)),'HorizontalAlignment','center','FontSize',6.5,'Color','white');
    end
end

sgtitle('ANN Sensitivity Analysis — Input Contribution to Outputs','FontSize',12,'FontWeight','bold');
saveas(fig13,'Fig13_Sensitivity_Analysis.png');

%% 5.3 — Figure 14: 3D surface Span × Settlement → Deflection ───────────────
fig14 = figure('Name','3D Span-Settlement-Deflection','NumberTitle','off','Position',[50 50 900 550]);
spanRange  = linspace(4, 8, 30);
deltaRange = linspace(0, 50, 30);
[SG, DG2]  = meshgrid(spanRange, deltaRange);
DEFL3D     = zeros(size(SG));

for r = 1:size(SG,1)
    for c = 1:size(SG,2)
        x_in      = median(X_raw);
        x_in(2)   = SG(r,c);    % span length
        x_in(4)   = DG2(r,c);   % settlement
        x_in_n    = mapminmax('apply', x_in', ps_X);
        y_out_n   = net_best(x_in_n);
        y_out     = mapminmax('reverse', y_out_n, ps_Y);
        DEFL3D(r,c) = y_out(4);
    end
end
surf(SG, DG2, DEFL3D,'EdgeAlpha',0.2,'FaceAlpha',0.92);
colormap(turbo); colorbar;
xlabel('Span Length (m)','FontSize',11);
ylabel('Settlement (mm)','FontSize',11);
zlabel('Deflection (mm)','FontSize',11);
title('3D Response: Span × Settlement → Midspan Deflection','FontSize',12,'FontWeight','bold');
view([-35 30]); grid on; lighting gouraud; camlight;
saveas(fig14,'Fig14_3D_Span_Settlement_Deflection.png');

%% 5.4 — Figure 15: Response envelopes by structure type ──────────────────────
fig15 = figure('Name','Structure Type Response Envelopes','NumberTitle','off',...
               'Position',[50 50 1200 600]);
deltas = 0:5:50;
colors15 = lines(4);
outputShow = [1, 3, 4];   % BM mid, Shear, Deflection
ylabels15  = {'BM Midspan (kN·m)','Shear Force (kN)','Deflection (mm)'};

for p = 1:3
    subplot(1,3,p); hold on;
    for st = 1:4
        env_vals = zeros(length(deltas),1);
        for d_i = 1:length(deltas)
            x_in    = median(X_raw);
            x_in(1) = st;
            x_in(4) = deltas(d_i);
            x_in_n  = mapminmax('apply', x_in', ps_X);
            y_out_n = net_best(x_in_n);
            y_out   = mapminmax('reverse', y_out_n, ps_Y);
            env_vals(d_i) = y_out(outputShow(p));
        end
        plot(deltas, env_vals, '-o', 'Color', colors15(st,:), ...
             'LineWidth', 1.8, 'MarkerSize', 5, 'DisplayName', structLabels{st});
    end
    hold off;
    xlabel('Settlement (mm)','FontSize',10);
    ylabel(ylabels15{p},'FontSize',10);
    title(ylabels15{p},'FontSize',11,'FontWeight','bold');
    legend('Location','northwest','FontSize',8);
    grid on; box off;
end
sgtitle('Structural Response Envelopes by Structure Type (T=40°C, Laterite Soil)',...
        'FontSize',12,'FontWeight','bold');
saveas(fig15,'Fig15_Response_Envelopes.png');

%% 5.5 — Figure 16: Soil influence on settlement-BM relationship ──────────────
fig16 = figure('Name','Soil Influence','NumberTitle','off','Position',[50 50 1000 480]);
subplot(1,2,1);
hold on;
for s = 1:4
    env_vals = zeros(length(deltas),1);
    for d_i = 1:length(deltas)
        x_in    = median(X_raw);
        x_in(9) = s;
        x_in(10)= SOIL_KS_arr(s);
        x_in(4) = deltas(d_i);
        x_in_n  = mapminmax('apply', x_in', ps_X);
        y_out_n = net_best(x_in_n);
        y_out   = mapminmax('reverse', y_out_n, ps_Y);
        env_vals(d_i) = y_out(1);
    end
    plot(deltas, env_vals,'-s','LineWidth',1.8,'MarkerSize',5,'DisplayName',soilLabels{s});
end
hold off;
xlabel('Settlement (mm)','FontSize',10);
ylabel('BM Midspan (kN·m)','FontSize',10);
title('Soil Type Effect on BM (T=40°C)','FontSize',11,'FontWeight','bold');
legend('FontSize',9,'Location','northwest'); grid on; box off;

subplot(1,2,2);
hold on;
for s = 1:4
    env_vals = zeros(length(deltas),1);
    for d_i = 1:length(deltas)
        x_in    = median(X_raw);
        x_in(9) = s;
        x_in(10)= SOIL_KS_arr(s);
        x_in(4) = deltas(d_i);
        x_in_n  = mapminmax('apply', x_in', ps_X);
        y_out_n = net_best(x_in_n);
        y_out   = mapminmax('reverse', y_out_n, ps_Y);
        env_vals(d_i) = y_out(4);
    end
    plot(deltas, env_vals,'-s','LineWidth',1.8,'MarkerSize',5,'DisplayName',soilLabels{s});
end
hold off;
xlabel('Settlement (mm)','FontSize',10);
ylabel('Deflection (mm)','FontSize',10);
title('Soil Type Effect on Deflection (T=40°C)','FontSize',11,'FontWeight','bold');
legend('FontSize',9,'Location','northwest'); grid on; box off;

sgtitle('Nigerian Soil Type Influence on Settlement-Induced Structural Response',...
        'FontSize',12,'FontWeight','bold');
saveas(fig16,'Fig16_Soil_Influence.png');

%% 5.6 — Figure 17: Temperature effect comparison (Nigeria context) ────────────
fig17 = figure('Name','Temperature Effect Comparison','NumberTitle','off',...
               'Position',[50 50 1000 500]);
temps_plot = 25:5:55;
subplot(1,2,1);
hold on;
for st = 1:4
    t_bm = zeros(length(temps_plot),1);
    for t_i = 1:length(temps_plot)
        x_in    = median(X_raw);
        x_in(1) = st;
        x_in(7) = temps_plot(t_i);
        x_in(4) = 0;   % no settlement — isolate temperature effect
        x_in_n  = mapminmax('apply', x_in', ps_X);
        y_out_n = net_best(x_in_n);
        y_out   = mapminmax('reverse', y_out_n, ps_Y);
        t_bm(t_i) = y_out(5);   % axial stress
    end
    plot(temps_plot, t_bm,'-^','LineWidth',1.8,'MarkerSize',6,'DisplayName',structLabels{st});
end
hold off;
xlabel('Temperature (°C)','FontSize',10);
ylabel('Axial Stress (MPa)','FontSize',10);
title('Temperature vs Axial Stress (δ=0)','FontSize',11,'FontWeight','bold');
legend('FontSize',8); grid on; box off;
% Nigerian climate reference lines
xline(35,'--','LineWidth',1.2,'Color',[0.7 0.4 0],'Label','Dry season avg');
xline(45,'--','LineWidth',1.2,'Color',[0.8 0.1 0.1],'Label','Peak hot season');

subplot(1,2,2);
hold on;
for st = 1:4
    t_defl = zeros(length(temps_plot),1);
    for t_i = 1:length(temps_plot)
        x_in    = median(X_raw);
        x_in(1) = st;
        x_in(7) = temps_plot(t_i);
        x_in(4) = 25;   % combined with moderate settlement
        x_in_n  = mapminmax('apply', x_in', ps_X);
        y_out_n = net_best(x_in_n);
        y_out   = mapminmax('reverse', y_out_n, ps_Y);
        t_defl(t_i) = y_out(4);
    end
    plot(temps_plot, t_defl,'-^','LineWidth',1.8,'MarkerSize',6,'DisplayName',structLabels{st});
end
hold off;
xlabel('Temperature (°C)','FontSize',10);
ylabel('Deflection (mm)','FontSize',10);
title('Temperature vs Deflection (δ=25mm)','FontSize',11,'FontWeight','bold');
legend('FontSize',8); grid on; box off;
xline(35,'--','LineWidth',1.2,'Color',[0.7 0.4 0]);
xline(45,'--','LineWidth',1.2,'Color',[0.8 0.1 0.1]);

sgtitle('Nigerian Hot Climate — Temperature Effects on Structural Response',...
        'FontSize',12,'FontWeight','bold');
saveas(fig17,'Fig17_Temperature_Effects_Nigeria.png');

fprintf('[STEP 5] COMPLETE. Figures 12–17 saved.\n\n');

% Helper
SOIL_KS_arr = [12000, 18000, 30000, 50000];
