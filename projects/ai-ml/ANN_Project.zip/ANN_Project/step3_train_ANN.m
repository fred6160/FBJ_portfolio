%% ============================================================
%  STEP 3 — ANN ARCHITECTURE DESIGN & TRAINING
%  File: step3_train_ANN.m
%
%  Strategy:
%   - Multi-output feedforward ANN (one network, 6 outputs)
%   - Architecture search over hidden-layer configurations
%   - Best network selected by validation MSE
%   - Training: Levenberg-Marquardt (trainlm) — fast convergence
%   - Regularisation: Bayesian (trainbr) — best generalisation
%   - Both trained; best one kept for deployment
% ============================================================
fprintf('[STEP 3] Designing and training ANN model...\n');

load('workspace_step1.mat');

% MATLAB Neural Network Toolbox uses column-major (features × samples)
Xtr = X_train';   Ytr = Y_train';
Xvl = X_val';     Yvl = Y_val';
Xte = X_test';    Yte = Y_test';

%% 3.1 — Architecture grid search ────────────────────────────────────────────
%  Test 6 candidate architectures and pick the best by validation RMSE.
%  This replaces arbitrary "pick 10 neurons" decisions with evidence.

architectures = {
    [16, 8],     ...   % A1: shallow wide
    [20, 10],    ...   % A2: moderate
    [24, 12],    ...   % A3: recommended baseline
    [32, 16],    ...   % A4: deeper
    [20, 10, 5], ...   % A5: 3-layer
    [30, 15, 8]  ...   % A6: 3-layer wider
};
archNames = {'[16-8]','[20-10]','[24-12]','[32-16]','[20-10-5]','[30-15-8]'};

fprintf('\n         --- ARCHITECTURE SEARCH (Levenberg-Marquardt, 3 trials each) ---\n');
fprintf('         %-14s  %10s  %10s  %10s\n','Architecture','Val RMSE','Val R²','Time(s)');
fprintf('         %s\n',repmat('-',1,52));

valRMSE_all = zeros(length(architectures),1);
for a = 1:length(architectures)
    hiddenSizes = architectures{a};
    rmse_trials = zeros(3,1);
    for trial = 1:3
        net_tmp = build_network(hiddenSizes, nInputs, nOutputs);
        net_tmp.divideFcn  = 'divideind';
        net_tmp.divideParam.trainInd = 1:size(Xtr,2);
        net_tmp.divideParam.valInd   = 1:size(Xvl,2);
        net_tmp.divideParam.testInd  = [];
        net_tmp.trainParam.showWindow = false;
        net_tmp.trainParam.epochs = 300;
        [net_tmp, ~] = train(net_tmp, [Xtr Xvl], [Ytr Yvl]);
        Yvl_pred     = net_tmp([Xvl]);
        rmse_trials(trial) = sqrt(mean((Yvl - Yvl_pred).^2,'all'));
    end
    valRMSE_all(a) = mean(rmse_trials);

    % R² on validation (normalised space)
    SS_res = sum((Yvl(:) - net_tmp(Xvl(:)) ).^2);
    SS_tot = sum((Yvl(:) - mean(Yvl(:))   ).^2);
    r2_val = 1 - SS_res/SS_tot;

    fprintf('         %-14s  %10.5f  %10.4f\n', archNames{a}, valRMSE_all(a), r2_val);
end

[~, bestArch] = min(valRMSE_all);
fprintf('\n         Best architecture: %s (Val RMSE = %.5f)\n', ...
        archNames{bestArch}, valRMSE_all(bestArch));

%% 3.2 — Train FINAL MODEL with best architecture (trainlm) ──────────────────
fprintf('\n         --- TRAINING FINAL MODEL (Levenberg-Marquardt) ---\n');

rng(42);
bestHidden = architectures{bestArch};
net_lm     = build_network(bestHidden, nInputs, nOutputs);

% Division: explicit index-based (we already split)
net_lm.divideFcn              = 'divideind';
net_lm.divideParam.trainInd   = 1 : size(Xtr,2);
net_lm.divideParam.valInd     = 1 : size(Xvl,2);
net_lm.divideParam.testInd    = 1 : size(Xte,2);

% Training parameters
net_lm.trainFcn               = 'trainlm';
net_lm.trainParam.epochs      = 1000;
net_lm.trainParam.goal        = 1e-6;
net_lm.trainParam.max_fail    = 20;      % early stopping patience
net_lm.trainParam.mu          = 0.001;
net_lm.trainParam.mu_dec      = 0.1;
net_lm.trainParam.mu_inc      = 10;
net_lm.trainParam.mu_max      = 1e10;
net_lm.trainParam.min_grad    = 1e-7;
net_lm.trainParam.showWindow  = true;    % shows training GUI
net_lm.trainParam.show        = 50;

tic;
[net_lm, tr_lm] = train(net_lm, [Xtr Xvl Xte], [Ytr Yvl Yte], ...
                         'useParallel','no');
t_lm = toc;
fprintf('         LM training complete in %.1f seconds. Best epoch: %d\n', ...
        t_lm, tr_lm.best_epoch);

%% 3.3 — Train Bayesian Regularisation variant (trainbr) ──────────────────────
fprintf('\n         --- TRAINING BAYESIAN REGULARISATION MODEL (trainbr) ---\n');
rng(42);
net_br             = build_network(bestHidden, nInputs, nOutputs);
net_br.trainFcn    = 'trainbr';
net_br.divideFcn   = 'dividerand';
net_br.divideParam.trainRatio = 0.85;
net_br.divideParam.valRatio   = 0.15;
net_br.divideParam.testRatio  = 0.00;
net_br.trainParam.epochs      = 1000;
net_br.trainParam.goal        = 1e-6;
net_br.trainParam.mu          = 0.005;
net_br.trainParam.showWindow  = true;
net_br.trainParam.show        = 50;

tic;
[net_br, tr_br] = train(net_br, Xtr, Ytr, 'useParallel','no');
t_br = toc;
fprintf('         BR training complete in %.1f seconds. Best epoch: %d\n', ...
        t_br, tr_br.best_epoch);

%% 3.4 — Select best model by test set performance ────────────────────────────
Yte_pred_lm = net_lm(Xte);
Yte_pred_br = net_br(Xte);

rmse_lm = sqrt(mean((Yte - Yte_pred_lm).^2, 'all'));
rmse_br = sqrt(mean((Yte - Yte_pred_br).^2, 'all'));

fprintf('\n         Test RMSE — LM: %.5f   BR: %.5f\n', rmse_lm, rmse_br);

if rmse_lm <= rmse_br
    net_best   = net_lm;
    tr_best    = tr_lm;
    modelName  = 'Levenberg-Marquardt';
    fprintf('         Selected model: LM\n');
else
    net_best   = net_br;
    tr_best    = tr_br;
    modelName  = 'Bayesian Regularisation';
    fprintf('         Selected model: BR\n');
end

%% 3.5 — Figure 7: Training performance curve ────────────────────────────────
fig7 = figure('Name','Training Performance','NumberTitle','off','Position',[100 100 900 420]);

subplot(1,2,1);
semilogy(tr_lm.epoch, tr_lm.perf, 'b-','LineWidth',1.8,'DisplayName','LM Train');
hold on;
if ~isempty(tr_lm.vperf)
    semilogy(tr_lm.epoch, tr_lm.vperf,'b--','LineWidth',1.5,'DisplayName','LM Val');
end
semilogy(tr_br.epoch, tr_br.perf,'r-','LineWidth',1.8,'DisplayName','BR Train');
if ~isempty(tr_br.vperf)
    semilogy(tr_br.epoch, tr_br.vperf,'r--','LineWidth',1.5,'DisplayName','BR Val');
end
hold off;
xlabel('Epoch','FontSize',10); ylabel('MSE (normalised)','FontSize',10);
title('Training Performance Curves','FontSize',11,'FontWeight','bold');
legend('Location','northeast','FontSize',8); grid on; box off;

subplot(1,2,2);
bar([rmse_lm, rmse_br], 'FaceColor',[0.2 0.47 0.71],'EdgeColor','white');
set(gca,'XTickLabel',{'LM','BR'},'FontSize',10);
ylabel('Test RMSE (norm.)','FontSize',10);
title('Model Comparison','FontSize',11,'FontWeight','bold');
grid on; box off;
text(1, rmse_lm+0.001, sprintf('%.5f',rmse_lm),'HorizontalAlignment','center','FontSize',9);
text(2, rmse_br+0.001, sprintf('%.5f',rmse_br),'HorizontalAlignment','center','FontSize',9);

sgtitle(sprintf('ANN Training — Best Architecture: %s', archNames{bestArch}), ...
        'FontSize',12,'FontWeight','bold');
saveas(fig7,'Fig7_Training_Performance.png');

%% 3.6 — Figure 8: Architecture diagram ─────────────────────────────────────
fig8 = figure('Name','ANN Architecture','NumberTitle','off','Position',[100 100 1000 500]);
plot_ann_architecture(nInputs, bestHidden, nOutputs);
saveas(fig8,'Fig8_ANN_Architecture.png');

%% 3.7 — Save ─────────────────────────────────────────────────────────────────
save('workspace_step3.mat', ...
     'net_best','net_lm','net_br','tr_best','tr_lm','tr_br', ...
     'bestHidden','bestArch','archNames','modelName', ...
     'Xtr','Ytr','Xvl','Yvl','Xte','Yte', ...
     'rmse_lm','rmse_br');

fprintf('[STEP 3] COMPLETE. Model saved to workspace_step3.mat\n\n');

%% ── Helper functions ──────────────────────────────────────────────────────

function net = build_network(hiddenSizes, nIn, nOut)
    net = feedforwardnet(hiddenSizes, 'trainlm');
    net.inputs{1}.size        = nIn;

    % Hidden layer activation: tansig (best for structural regression)
    for L = 1:length(hiddenSizes)
        net.layers{L}.transferFcn = 'tansig';
    end
    % Output layer: linear (purelin) for regression
    net.layers{end}.transferFcn = 'purelin';

    % Performance: MSE
    net.performFcn            = 'mse';
    net.trainParam.showWindow = false;
end

function plot_ann_architecture(nIn, hidden, nOut)
    % Simple schematic of ANN layers
    ax = gca; hold(ax,'on');
    layerSizes  = [nIn, hidden, nOut];
    nLayers     = length(layerSizes);
    layerNames  = [{'Input'}, arrayfun(@(x) sprintf('Hidden %d',x), ...
                   1:length(hidden),'UniformOutput',false), {'Output'}];
    maxNodes    = max(layerSizes);
    colors      = {[0.2 0.47 0.71], repmat({[0.12 0.63 0.37]},1,length(hidden)){:}, ...
                   [0.84 0.19 0.15]};
    if iscell(colors{1}); colors{1} = [0.2 0.47 0.71]; end

    xSpacing    = 3;
    rNode       = 0.22;

    for L = 1:nLayers
        nN    = min(layerSizes(L), 14);   % cap display nodes
        xPos  = (L-1) * xSpacing;
        yOff  = (maxNodes - nN) / 2;
        col   = colors{min(L,end)};
        if iscell(col); col = col{1}; end

        for n = 1:nN
            yPos = yOff + n - 1;
            rectangle('Position',[xPos-rNode, yPos-rNode, 2*rNode, 2*rNode], ...
                      'Curvature',[1 1],'FaceColor',col,'EdgeColor','white','LineWidth',1);
        end
        if layerSizes(L) > 14
            text(xPos, yOff-0.8, '⋮','HorizontalAlignment','center','FontSize',16);
        end
        text(xPos, -1.5, sprintf('%s\n(%d)', layerNames{L}, layerSizes(L)), ...
             'HorizontalAlignment','center','FontSize',8,'FontWeight','bold');

        % Connections to next layer
        if L < nLayers
            nN2    = min(layerSizes(L+1), 14);
            yOff2  = (maxNodes - nN2) / 2;
            xPos2  = L * xSpacing;
            for n1 = 1:min(nN,6)
                y1 = yOff + n1 - 1;
                for n2 = 1:min(nN2,6)
                    y2 = yOff2 + n2 - 1;
                    line([xPos+rNode, xPos2-rNode],[y1, y2], ...
                         'Color',[0.7 0.7 0.7],'LineWidth',0.4,'HandleVisibility','off');
                end
            end
        end
    end
    axis off; hold off;
    title(sprintf('ANN Architecture: %d → %s → %d', nIn, ...
                  strjoin(arrayfun(@num2str,hidden,'UniformOutput',false),'→'), nOut), ...
          'FontSize',12,'FontWeight','bold');
end
