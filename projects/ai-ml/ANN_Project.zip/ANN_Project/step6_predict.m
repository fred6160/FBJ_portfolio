%% ============================================================
%  STEP 6 — PREDICTION INTERFACE
%  File: step6_predict.m
%
%  Provides a clean function to use the trained ANN for
%  predicting structural responses given new input scenarios.
%
%  Usage (after running main_ANN.m):
%    >> result = predict_response(settlement, temperature, ...
%                                 span, struct_type, soil_type, ...
%                                 subgrade_mod, load_combo)
%
%  Or run this script directly to see 5 worked examples.
% ============================================================
fprintf('[STEP 6] Running prediction examples...\n');

load('workspace_step1.mat');
load('workspace_step3.mat');

%% 6.1 — Define prediction function ─────────────────────────────────────────
%
%  INPUT ENCODING GUIDE:
%  ┌─────────────────────────┬──────────────────────────────────────────────┐
%  │  struct_type            │  1=2-Span Beam  2=3-Span Beam               │
%  │                         │  3=Portal Frame  4=Multi-bay Frame          │
%  ├─────────────────────────┼──────────────────────────────────────────────┤
%  │  settle_loc_code        │  0=None  1=End A  2=Interior B              │
%  │                         │  3=Both B&C  4=Multiple                     │
%  ├─────────────────────────┼──────────────────────────────────────────────┤
%  │  settle_type_code       │  0=N/A  1=Uniform  2=Differential           │
%  ├─────────────────────────┼──────────────────────────────────────────────┤
%  │  temp_type_code         │  1=Uniform  2=Gradient                      │
%  ├─────────────────────────┼──────────────────────────────────────────────┤
%  │  soil_type_code         │  1=Clay Expansive  2=Sandy Clay             │
%  │                         │  3=Laterite  4=Dense Sand                   │
%  ├─────────────────────────┼──────────────────────────────────────────────┤
%  │  load_combo_code        │  1=1.35DL+1.5LL  2=EC2 ULS  3=1.0DL+1.0LL │
%  └─────────────────────────┴──────────────────────────────────────────────┘

%% 6.2 — Five worked prediction scenarios ────────────────────────────────────
%
%  Scenarios representative of Nigerian practice:
%
%  S1: Typical residential 2-span beam, laterite soil, mild settlement
%  S2: Commercial 3-span beam, clay soil, heavy settlement, hot season
%  S3: Portal frame, sandy clay, moderate settlement, gradient temperature
%  S4: Multi-bay frame, dense sand, no settlement, peak temperature
%  S5: Critical case — maximum settlement + peak temperature + soft clay

scenarios = {
%  Struct  Span  nSpan  Settle  SLoc  SType  Temp  TType  Soil  Ks     LC   Label
   1,      6.0,  2,     10,     2,    2,     35,   1,     3,    30000, 1,   '2-Span Beam, 35°C, δ=10mm, Laterite';
   2,      6.0,  3,     25,     2,    2,     45,   1,     1,    12000, 1,   '3-Span Beam, 45°C, δ=25mm, Clay';
   3,      6.0,  2,     20,     2,    2,     40,   2,     2,    18000, 2,   'Portal Frame, 40°C, δ=20mm, Sandy Clay';
   4,      6.0,  3,     0,      0,    0,     55,   1,     4,    50000, 2,   'Multi-bay Frame, 55°C, δ=0mm, Dense Sand';
   1,      8.0,  2,     50,     3,    1,     55,   2,     1,    12000, 1,   'CRITICAL: 2-Span, 55°C, δ=50mm, Soft Clay';
};

outputLabels = {'BM Midspan (kN·m)', 'BM Support (kN·m)', ...
                'Shear Force (kN)',   'Deflection (mm)', ...
                'Axial Stress (MPa)', 'Shear Stress (MPa)'};

fprintf('\n');
fprintf('  ╔══════════════════════════════════════════════════════════════════════╗\n');
fprintf('  ║           ANN STRUCTURAL RESPONSE PREDICTIONS                       ║\n');
fprintf('  ║           Nigeria Hot Climate — Settlement & Temperature Study       ║\n');
fprintf('  ╚══════════════════════════════════════════════════════════════════════╝\n\n');

all_predictions = zeros(5, 6);

for s = 1:5
    row = scenarios(s,:);
    label = row{12};

    % Build input vector [1×11]: matches training feature order
    x_new = [row{1}, row{2}, row{3}, row{4}, row{5}, row{6}, ...
             row{7}, row{8}, row{9}, row{10}, row{11}];

    % Normalise
    x_new_n = mapminmax('apply', x_new', ps_X);

    % Predict
    y_pred_n = net_best(x_new_n);

    % Denormalise
    y_pred = mapminmax('reverse', y_pred_n, ps_Y);

    all_predictions(s,:) = y_pred';

    % Display
    fprintf('  ── Scenario %d: %s\n', s, label);
    fprintf('     Input:   Span=%.0fm  Settlement=%.0fmm  Temp=%.0f°C\n', ...
            row{2}, row{4}, row{7});
    fprintf('     ┌─────────────────────────────────────────────────────┐\n');
    fprintf('     │  BM Midspan      : %8.2f kN·m                    │\n', y_pred(1));
    fprintf('     │  BM Support      : %8.2f kN·m                    │\n', y_pred(2));
    fprintf('     │  Max Shear       : %8.2f kN                      │\n', y_pred(3));
    fprintf('     │  Midspan Deflect.: %8.3f mm                      │\n', y_pred(4));
    fprintf('     │  Axial Stress    : %8.4f MPa                     │\n', y_pred(5));
    fprintf('     │  Shear Stress    : %8.4f MPa                     │\n', y_pred(6));
    fprintf('     └─────────────────────────────────────────────────────┘\n');

    % Serviceability checks (EC2 / BS 8110)
    span_m = row{2};
    defl_limit = span_m * 1000 / 250;   % L/250 SLS limit
    stress_limit = 0.45 * 25;           % 0.45fcu for C25

    fprintf('     Checks: Deflection limit L/250 = %.1f mm → %s\n', ...
            defl_limit, check_str(y_pred(4), defl_limit));
    fprintf('             Stress limit 0.45fcu = %.1f MPa → %s\n\n', ...
            stress_limit, check_str(y_pred(5), stress_limit));
end

%% 6.3 — Figure 18: Scenario comparison bar chart ────────────────────────────
fig18 = figure('Name','Scenario Predictions','NumberTitle','off','Position',[50 50 1300 600]);
scenario_labels = {'S1: Residential\nBeam 35°C', 'S2: Commercial\nBeam 45°C', ...
                   'S3: Portal Frame\n40°C', 'S4: Multi-bay\n55°C No-settle', ...
                   'S5: CRITICAL\n55°C δ=50mm'};
output_show = [1, 3, 4, 5];   % BM, Shear, Deflection, Stress
ylabels18   = {'BM Midspan (kN·m)','Shear Force (kN)','Deflection (mm)','Axial Stress (MPa)'};

colors18 = [0.20 0.47 0.71; 0.84 0.19 0.15; 0.20 0.63 0.17; 0.89 0.55 0.00];

for p = 1:4
    subplot(2,2,p);
    vals = all_predictions(:, output_show(p));
    b = bar(vals, 'FaceColor','flat','EdgeColor','white');
    for k = 1:5
        b.CData(k,:) = colors18(min(k,4),:) * (0.7 + 0.3*(k==5));
    end
    set(gca,'XTickLabel',{'S1','S2','S3','S4','S5 ⚠'},'FontSize',9);
    ylabel(ylabels18{p},'FontSize',9);
    title(ylabels18{p},'FontSize',10,'FontWeight','bold');
    grid on; box off;
    for k = 1:5
        text(k, vals(k)+0.01*max(vals), sprintf('%.1f',vals(k)), ...
             'HorizontalAlignment','center','FontSize',8);
    end
    if output_show(p) == 4  % deflection — add L/250 line per scenario
        yline(16,'r--','L/250','LineWidth',1.2);
    end
end
sgtitle('Predicted Structural Responses — Five Nigerian Practice Scenarios',...
        'FontSize',12,'FontWeight','bold');
saveas(fig18,'Fig18_Scenario_Predictions.png');

%% 6.4 — Figure 19: Settlement progression for critical scenario ──────────────
fig19 = figure('Name','Settlement Progression','NumberTitle','off','Position',[50 50 1100 500]);
d_prog = 0:2:50;
resp_prog = zeros(length(d_prog), 6);

for d_i = 1:length(d_prog)
    % Use S5 settings but vary settlement
    x_new   = [1, 8.0, 2, d_prog(d_i), 3, 1, 55, 2, 1, 12000, 1];
    x_new_n = mapminmax('apply', x_new', ps_X);
    y_n     = net_best(x_new_n);
    y       = mapminmax('reverse', y_n, ps_Y);
    resp_prog(d_i,:) = y';
end

subplot(1,3,1);
plot(d_prog, resp_prog(:,1),'b-','LineWidth',2,'DisplayName','BM Midspan');
hold on;
plot(d_prog, abs(resp_prog(:,2)),'r-','LineWidth',2,'DisplayName','|BM Support|');
hold off;
xlabel('Settlement (mm)'); ylabel('BM (kN·m)');
title('BM vs Settlement Progression','FontSize',10,'FontWeight','bold');
legend('FontSize',8); grid on; box off;

subplot(1,3,2);
plot(d_prog, resp_prog(:,4),'g-','LineWidth',2);
hold on;
yline(8000/250,'r--','L/250 Limit','LineWidth',1.5);
hold off;
xlabel('Settlement (mm)'); ylabel('Deflection (mm)');
title('Deflection vs Settlement','FontSize',10,'FontWeight','bold');
grid on; box off;

subplot(1,3,3);
plot(d_prog, resp_prog(:,5),'m-','LineWidth',2);
hold on;
yline(0.45*25,'r--','0.45f_{cu}','LineWidth',1.5);
hold off;
xlabel('Settlement (mm)'); ylabel('Axial Stress (MPa)');
title('Stress vs Settlement','FontSize',10,'FontWeight','bold');
grid on; box off;

sgtitle('Critical Scenario: Settlement Progression at 55°C, Soft Clay (2-Span, 8m)',...
        'FontSize',11,'FontWeight','bold');
saveas(fig19,'Fig19_Settlement_Progression.png');

fprintf('[STEP 6] COMPLETE. Prediction examples shown above.\n');
fprintf('         Call predict_response() directly for new scenarios.\n\n');

%% ── Convenience wrapper function ──────────────────────────────────────────
function result = predict_response(settlement_mm, temperature_C, ...
                                    span_m, struct_type, soil_type, ...
                                    subgrade_mod, load_combo)
    % Loads trained model and returns predicted structural responses.
    % Uses median values for unspecified parameters.
    %
    % Example:
    %   result = predict_response(15, 42, 6, 1, 3, 30000, 1)

    load('workspace_step1.mat','ps_X','ps_Y','X_raw');
    load('workspace_step3.mat','net_best');

    % Auto-set settlement location/type based on magnitude
    if settlement_mm == 0
        s_loc = 0; s_type = 0;
    elseif settlement_mm <= 15
        s_loc = 2; s_type = 2;
    else
        s_loc = 3; s_type = 1;
    end

    n_spans   = 2 + (struct_type >= 2);
    temp_type = 1;   % default uniform
    if temperature_C >= 45; temp_type = 2; end

    x_new   = [struct_type, span_m, n_spans, settlement_mm, s_loc, s_type, ...
               temperature_C, temp_type, soil_type, subgrade_mod, load_combo];
    x_new_n = mapminmax('apply', x_new', ps_X);
    y_n     = net_best(x_new_n);
    y       = mapminmax('reverse', y_n, ps_Y);

    result = struct( ...
        'BM_midspan_kNm',    y(1), ...
        'BM_support_kNm',    y(2), ...
        'Shear_kN',          y(3), ...
        'Deflection_mm',     y(4), ...
        'AxialStress_MPa',   y(5), ...
        'ShearStress_MPa',   y(6)  ...
    );
end

function s = check_str(val, limit)
    if val <= limit
        s = sprintf('✓ OK (%.3f ≤ %.1f)', val, limit);
    else
        s = sprintf('✗ EXCEEDS (%.3f > %.1f)', val, limit);
    end
end
