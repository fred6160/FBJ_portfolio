%% ============================================================
%  README — HOW TO RUN THIS PROJECT IN MATLAB
%  File: README_MATLAB.m
%  Read this first before running anything.
% ============================================================
%
%  ┌──────────────────────────────────────────────────────────┐
%  │  PROJECT: ANN for Settlement & Temperature Effects on    │
%  │           Indeterminate Structures — Nigeria Hot Climate │
%  │  Author:  [Student Name]                                 │
%  │  Supervisor: Prof. S.M. Auta                            │
%  │  Institution: FUT Minna, Civil Engineering Dept.        │
%  └──────────────────────────────────────────────────────────┘
%
%  ═══════════════════════════════════════════════════════════
%  REQUIRED MATLAB TOOLBOXES
%  ═══════════════════════════════════════════════════════════
%  1. Deep Learning Toolbox (neural network training)
%  2. Statistics and Machine Learning Toolbox (correlation, boxplot)
%  3. Curve Fitting Toolbox (optional, for polyfit visualisation)
%
%  MATLAB Version: R2020b or later recommended.
%
%  ═══════════════════════════════════════════════════════════
%  FILE STRUCTURE
%  ═══════════════════════════════════════════════════════════
%  Place ALL the following files in ONE folder:
%
%  📁 ANN_Project/
%  ├── ANN_Full_Dataset.csv      ← The dataset (2836 rows)
%  ├── README_MATLAB.m           ← This file
%  ├── main_ANN.m                ← MASTER RUNNER (run this)
%  ├── step1_load_preprocess.m   ← Data loading & normalisation
%  ├── step2_EDA.m               ← Exploratory data analysis
%  ├── step3_train_ANN.m         ← ANN training & architecture search
%  ├── step4_evaluate.m          ← Performance metrics & plots
%  ├── step5_visualise.m         ← Advanced response visualisations
%  └── step6_predict.m           ← Prediction interface & examples
%
%  ═══════════════════════════════════════════════════════════
%  HOW TO RUN
%  ═══════════════════════════════════════════════════════════
%  OPTION A — Run everything (recommended):
%    1. Open MATLAB
%    2. Set working directory to the ANN_Project/ folder
%    3. Type in Command Window:   >> run('main_ANN.m')
%    4. Wait ~5–15 minutes for training to complete
%    5. All figures and results appear automatically
%
%  OPTION B — Run individual steps:
%    >> run('step1_load_preprocess.m')   % Load data first
%    >> run('step2_EDA.m')               % Then EDA
%    >> run('step3_train_ANN.m')         % Train the model
%    >> run('step4_evaluate.m')          % Evaluate performance
%    >> run('step5_visualise.m')         % Generate plots
%    >> run('step6_predict.m')           % Run predictions
%
%  OPTION C — Predict for a new scenario:
%    After running main_ANN.m at least once:
%    >> result = predict_response(15, 42, 6, 1, 3, 30000, 1)
%    %          (settlement_mm, temp_C, span_m, struct_type,
%    %           soil_type, subgrade_mod, load_combo)
%    >> disp(result)
%
%  ═══════════════════════════════════════════════════════════
%  OUTPUT FILES GENERATED
%  ═══════════════════════════════════════════════════════════
%  Workspace files (auto-generated, needed between steps):
%    workspace_step1.mat  — preprocessed data, normalisation params
%    workspace_step3.mat  — trained ANN model
%    workspace_step4.mat  — evaluation metrics
%
%  Figures saved as PNG:
%    Fig01_Input_Distributions.png
%    Fig02_Output_Distributions.png
%    Fig03_Correlation_Heatmap.png
%    Fig04_Settlement_vs_BM.png
%    Fig05_Temperature_Effects.png
%    Fig06_Deflection_Boxplots.png
%    Fig07_Training_Performance.png
%    Fig08_ANN_Architecture.png
%    Fig09_Predicted_vs_Actual.png
%    Fig10_Residuals.png
%    Fig11_Performance_Summary.png
%    Fig12_Response_Surfaces.png
%    Fig13_Sensitivity_Analysis.png
%    Fig14_3D_Span_Settlement_Deflection.png
%    Fig15_Response_Envelopes.png
%    Fig16_Soil_Influence.png
%    Fig17_Temperature_Effects_Nigeria.png
%    Fig18_Scenario_Predictions.png
%    Fig19_Settlement_Progression.png
%
%  ═══════════════════════════════════════════════════════════
%  ENCODING GUIDE (for predict_response and manual inputs)
%  ═══════════════════════════════════════════════════════════
%  struct_type:    1=2-Span Beam  2=3-Span Beam
%                  3=Portal Frame  4=Multi-bay Frame
%
%  settle_loc_code: 0=None  1=End Support A  2=Interior B
%                   3=Both B&C  4=Multiple Supports
%
%  settle_type_code: 0=N/A  1=Uniform  2=Differential
%
%  temp_type_code:  1=Uniform  2=Gradient
%
%  soil_type_code:  1=Clay Expansive  2=Sandy Clay
%                   3=Laterite  4=Dense Sand
%
%  load_combo_code: 1=1.35DL+1.5LL+T+S  2=EC2 ULS  3=1.0DL+1.0LL
%
%  ═══════════════════════════════════════════════════════════
%  TROUBLESHOOTING
%  ═══════════════════════════════════════════════════════════
%  Error: "feedforwardnet not found"
%    → Install Deep Learning Toolbox (Home → Add-Ons)
%
%  Error: "ANN_Full_Dataset.csv not found"
%    → Check working directory: >> pwd
%    → Change to correct folder: >> cd('C:\path\to\ANN_Project')
%
%  Error: "workspace_step1.mat not found"
%    → Run step1_load_preprocess.m before other steps
%
%  Training takes too long:
%    → In step3_train_ANN.m, reduce epochs from 1000 to 300
%    → Or reduce architectures list to just {[20,10]} for quick test
%
%  Poor R² (<0.95):
%    → Increase max epochs to 2000
%    → Try architecture [32,16,8] (add to the architectures cell array)
%    → Ensure dataset is clean (no NaNs in CSV)
%
%  ═══════════════════════════════════════════════════════════
%  EXPECTED PERFORMANCE (from AI-generated dataset)
%  ═══════════════════════════════════════════════════════════
%  With this dataset and the default settings, you should
%  expect on the test set:
%    R² > 0.98 for most outputs
%    MAPE < 5% for BM and Shear
%    MAPE < 8% for Deflection and Stress
%
%  If using real ETABS data, results may vary depending on
%  data quality and parameter coverage.
%
%  ═══════════════════════════════════════════════════════════

fprintf('README loaded. Run main_ANN.m to start the project.\n');
