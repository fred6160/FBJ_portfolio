%% ============================================================
%  STEP 4 — MODEL EVALUATION & PERFORMANCE METRICS
%  File: step4_evaluate.m
%
%  Metrics computed (on test set, in ORIGINAL units):
%    • R²   — coefficient of determination
%    • RMSE — root mean squared error
%    • MAE  — mean absolute error
%    • MAPE — mean absolute percentage error
%    • NSE  — Nash-Sutcliffe Efficiency
%    • Max Error — worst-case prediction error
% ============================================================
fprintf('[STEP 4] Evaluating model performance...\n');

load('workspace_step1.mat');
load('workspace_step3.mat');

outputLabels = {'BM Midspan (kN·m)', 'BM Support (kN·m)', ...
                'Shear Force (kN)',   'Deflection (mm)', ...
                'Axial Stress (MPa)', 'Shear Stress (MPa)'};
outputUnits  = {'kN·m','kN·m','kN','mm','MPa','MPa'};

%% 4.1 — Generate predictions on all three splits ─────────────────────────────
Ytr_pred_n = net_best(Xtr);
Yvl_pred_n = net_best(Xvl);
Yte_pred_n = net_best(Xte);

% Denormalise back to physical units
Ytr_pred = mapminmax('reverse', Ytr_pred_n, ps_Y)';
Yvl_pred = mapminmax('reverse', Yvl_pred_n, ps_Y)';
Yte_pred = mapminmax('reverse', Yte_pred_n, ps_Y)';

% Actual values (denormalised)
Ytr_act = mapminmax('reverse', Ytr, ps_Y)';
Yvl_act = mapminmax('reverse', Yvl, ps_Y)';
Yte_act = mapminmax('reverse', Yte, ps_Y)';

%% 4.2 — Compute per-output metrics (test set) ───────────────────────────────
nOut = size(Yte_act,2);
metrics = struct();

fprintf('\n         --- TEST SET PERFORMANCE (Physical Units) ---\n');
fprintf('         %-22s %8s %10s %10s %10s %10s\n', ...
        'Output','R²','RMSE','MAE','MAPE(%)','NSE');
fprintf('         %s\n', repmat('-',1,78));

R2_all   = zeros(nOut,1);
RMSE_all = zeros(nOut,1);
MAE_all  = zeros(nOut,1);
MAPE_all = zeros(nOut,1);
NSE_all  = zeros(nOut,1);

for i = 1:nOut
    act  = Yte_act(:,i);
    pred = Yte_pred(:,i);

    ss_res  = sum((act - pred).^2);
    ss_tot  = sum((act - mean(act)).^2);
    R2      = 1 - ss_res / ss_tot;
    RMSE    = sqrt(mean((act - pred).^2));
    MAE     = mean(abs(act - pred));
    MAPE    = mean(abs((act - pred) ./ act)) * 100;
    NSE     = 1 - sum((act-pred).^2) / sum((act-mean(act)).^2);

    R2_all(i)   = R2;
    RMSE_all(i) = RMSE;
    MAE_all(i)  = MAE;
    MAPE_all(i) = MAPE;
    NSE_all(i)  = NSE;

    fprintf('         %-22s %8.4f %10.3f %10.3f %10.2f %10.4f\n', ...
            outputLabels{i}, R2, RMSE, MAE, MAPE, NSE);
end

fprintf('         %s\n', repmat('-',1,78));
fprintf('         %-22s %8.4f %10.3f %10.3f %10.2f %10.4f\n', ...
        'OVERALL AVERAGE', mean(R2_all), mean(RMSE_all), ...
        mean(MAE_all), mean(MAPE_all), mean(NSE_all));

%% 4.3 — Performance across train / val / test ────────────────────────────────
fprintf('\n         --- OVERALL R² BY SPLIT ---\n');
for split_name = {'Training','Validation','Test'}
    if strcmp(split_name{1},'Training')
        a = Ytr_act; p = Ytr_pred;
    elseif strcmp(split_name{1},'Validation')
        a = Yvl_act; p = Yvl_pred;
    else
        a = Yte_act; p = Yte_pred;
    end
    ss_res_all = sum((a(:) - p(:)).^2);
    ss_tot_all = sum((a(:) - mean(a(:))).^2);
    r2_overall = 1 - ss_res_all/ss_tot_all;
    fprintf('         %-14s R² = %.4f\n', split_name{1}, r2_overall);
end

%% 4.4 — Figure 9: Predicted vs Actual scatter (all 6 outputs) ───────────────
fig9 = figure('Name','Predicted vs Actual','NumberTitle','off','Position',[50 50 1300 700]);
colors9 = lines(6);

for i = 1:nOut
    subplot(2,3,i);
    act  = Yte_act(:,i);
    pred = Yte_pred(:,i);

    scatter(act, pred, 18, colors9(i,:), 'filled', 'MarkerFaceAlpha', 0.55);
    hold on;
    % Perfect prediction line
    lims = [min([act;pred]), max([act;pred])];
    plot(lims, lims, 'k--', 'LineWidth', 1.5, 'DisplayName', '1:1 Line');
    % Best-fit line
    p_fit = polyfit(act, pred, 1);
    xfit  = linspace(lims(1), lims(2), 100);
    plot(xfit, polyval(p_fit, xfit), 'r-', 'LineWidth', 1.5, 'DisplayName', 'Best Fit');
    hold off;

    xlabel(sprintf('Actual (%s)', outputUnits{i}), 'FontSize', 9);
    ylabel(sprintf('Predicted (%s)', outputUnits{i}), 'FontSize', 9);
    title(outputLabels{i}, 'FontSize', 10, 'FontWeight', 'bold');
    legend('Data','1:1','Fit','Location','northwest','FontSize',7);
    text(0.05, 0.92, sprintf('R² = %.4f\nRMSE = %.3f\nMAPE = %.1f%%', ...
         R2_all(i), RMSE_all(i), MAPE_all(i)), ...
         'Units','normalized','FontSize',8,'BackgroundColor',[1 1 1 0.7]);
    grid on; box off;
end
sgtitle('ANN Predicted vs Actual — Test Set','FontSize',13,'FontWeight','bold');
saveas(fig9,'Fig9_Predicted_vs_Actual.png');

%% 4.5 — Figure 10: Residual plots ───────────────────────────────────────────
fig10 = figure('Name','Residual Analysis','NumberTitle','off','Position',[50 50 1300 700]);
for i = 1:nOut
    act      = Yte_act(:,i);
    pred     = Yte_pred(:,i);
    residuals = pred - act;

    subplot(2,3,i);
    scatter(act, residuals, 15, colors9(i,:), 'filled', 'MarkerFaceAlpha', 0.55);
    hold on;
    yline(0, 'k--', 'LineWidth', 1.5);
    yline( 2*std(residuals), 'r:', 'LineWidth', 1, 'Label', '+2σ');
    yline(-2*std(residuals), 'r:', 'LineWidth', 1, 'Label', '-2σ');
    hold off;

    xlabel(sprintf('Actual (%s)', outputUnits{i}), 'FontSize', 9);
    ylabel('Residual (Pred - Actual)', 'FontSize', 9);
    title(outputLabels{i}, 'FontSize', 10, 'FontWeight', 'bold');
    grid on; box off;
    pct_in2sig = sum(abs(residuals) < 2*std(residuals)) / numel(residuals) * 100;
    text(0.05, 0.92, sprintf('%.1f%% within 2σ', pct_in2sig), ...
         'Units','normalized','FontSize',8,'BackgroundColor',[1 1 1 0.7]);
end
sgtitle('Residual Analysis — Test Set','FontSize',13,'FontWeight','bold');
saveas(fig10,'Fig10_Residuals.png');

%% 4.6 — Figure 11: Performance summary bar chart ────────────────────────────
fig11 = figure('Name','Performance Summary','NumberTitle','off','Position',[100 100 1000 420]);
subplot(1,2,1);
barh(R2_all, 'FaceColor',[0.2 0.63 0.17],'EdgeColor','white');
set(gca,'YTickLabel',outputLabels,'FontSize',9);
xlabel('R² (Test Set)','FontSize',10); xlim([0 1]);
title('R² per Output Variable','FontSize',11,'FontWeight','bold');
xline(0.99,'r--','R²=0.99','LineWidth',1.5);
grid on; box off;

subplot(1,2,2);
barh(MAPE_all,'FaceColor',[0.84 0.19 0.15],'EdgeColor','white');
set(gca,'YTickLabel',outputLabels,'FontSize',9);
xlabel('MAPE % (Test Set)','FontSize',10);
title('MAPE % per Output Variable','FontSize',11,'FontWeight','bold');
xline(5,'r--','5% threshold','LineWidth',1.5);
grid on; box off;

sgtitle('Model Performance Summary','FontSize',12,'FontWeight','bold');
saveas(fig11,'Fig11_Performance_Summary.png');

%% 4.7 — Save ─────────────────────────────────────────────────────────────────
save('workspace_step4.mat', ...
     'R2_all','RMSE_all','MAE_all','MAPE_all','NSE_all', ...
     'Ytr_act','Ytr_pred','Yvl_act','Yvl_pred','Yte_act','Yte_pred', ...
     'outputLabels','outputUnits');

fprintf('\n[STEP 4] COMPLETE. Evaluation saved.\n\n');
