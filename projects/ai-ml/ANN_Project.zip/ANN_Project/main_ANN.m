%% ============================================================
%  ANN FOR SETTLEMENT & TEMPERATURE EFFECTS ON INDETERMINATE
%  STRUCTURES IN HOT CLIMATE REGIONS (NIGERIA)
%
%  Federal University of Technology, Minna
%  Dept. of Civil & Environmental Engineering
%  Supervisor: Prof. S.M. Auta
%
%  Script:  main_ANN.m
%  Purpose: Master runner — calls all sub-modules in sequence
%  Usage:   Run this file. All other scripts are called automatically.
%  MATLAB:  R2020b or later | Toolboxes: Deep Learning, Statistics
% ============================================================

clc; clear; close all;
fprintf('=============================================================\n');
fprintf('  ANN MODEL — STRUCTURAL SETTLEMENT & TEMPERATURE EFFECTS\n');
fprintf('  Nigeria Hot Climate Study\n');
fprintf('=============================================================\n\n');

%% ── STEP 1: Load and pre-process dataset ──────────────────────────────────
run('step1_load_preprocess.m');

%% ── STEP 2: Exploratory Data Analysis (EDA) ──────────────────────────────
run('step2_EDA.m');

%% ── STEP 3: ANN Architecture definition and training ─────────────────────
run('step3_train_ANN.m');

%% ── STEP 4: Model evaluation and performance metrics ─────────────────────
run('step4_evaluate.m');

%% ── STEP 5: Visualisations (prediction plots, sensitivity, responses) ────
run('step5_visualise.m');

%% ── STEP 6: Prediction interface (new inputs → structural response) ───────
run('step6_predict.m');

fprintf('\n=============================================================\n');
fprintf('  ALL STEPS COMPLETE. See Figures and results in workspace.\n');
fprintf('=============================================================\n');
