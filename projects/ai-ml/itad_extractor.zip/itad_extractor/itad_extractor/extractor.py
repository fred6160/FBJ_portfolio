# ============================================================
# extractor.py — Azure OpenAI Member Extraction
# (same logic as notebook Cell 4 — modularised)
# ============================================================

import json
from azure.identity import ClientSecretCredential, get_bearer_token_provider
from openai import AzureOpenAI
from config import (
    AZURE_ENDPOINT, AZURE_TENANT_ID, AZURE_CLIENT_ID,
    AZURE_CLIENT_SECRET, DEPLOYMENT_NAME, API_VERSION,
    MAX_TEXT_LENGTH
)


def _build_client() -> AzureOpenAI:
    """Build and return an authenticated Azure OpenAI client."""
    credential = ClientSecretCredential(
        tenant_id     = AZURE_TENANT_ID,
        client_id     = AZURE_CLIENT_ID,
        client_secret = AZURE_CLIENT_SECRET
    )
    token_provider = get_bearer_token_provider(
        credential,
        "https://cognitiveservices.azure.com/.default"
    )
    return AzureOpenAI(
        azure_endpoint          = AZURE_ENDPOINT,
        azure_ad_token_provider = token_provider,
        api_version             = API_VERSION
    )


# Single shared client instance
_client = _build_client()


SYSTEM_PROMPT = """
You are an ITU document analysis assistant.
Your task is to extract all supporting members mentioned in the document text.

Supporting members may include:
- companies, telecom operators, countries, administrations,
  regulators, ministries, universities, consortiums,
  standards organizations, regional groups, institutional entities,
  sector members

Extract entities explicitly mentioned as supporting, contributing,
participating, endorsing, backing, submitting, or jointly preparing
the work item, proposal, recommendation, study question, contribution,
or document.

Do NOT extract:
- person names, meeting locations, technical terms,
  recommendation numbers, study group identifiers,
  working party identifiers, document codes, timestamps,
  or document metadata

Rules:
- Extract only entities explicitly mentioned in the text.
- Do NOT invent or guess supporting members.
- Return ONLY valid JSON. No explanations, notes, or markdown.
- Each item must contain exactly one key: "supporting_member"
- If no supporting members are found, return: []

Example valid output:
[
  {"supporting_member": "Huawei Technologies"},
  {"supporting_member": "Egypt"},
  {"supporting_member": "GSMA"}
]
"""


def extract_members_from_text(text: str) -> list[str]:
    """
    Extract supporting member names from free text using Azure OpenAI.

    Parameters:
        text : Raw document text

    Returns:
        List of extracted member name strings
    """
    truncated = text[:MAX_TEXT_LENGTH] if len(text) > MAX_TEXT_LENGTH else text

    if not truncated.strip():
        return []

    user_prompt = f"""
Extract all supporting members from the following ITU document text.
Return ONLY a valid JSON array.

Example format:
[
  {{"supporting_member": "Huawei Technologies"}},
  {{"supporting_member": "Egypt"}}
]

Document text:
\"\"\"{truncated}\"\"\""""

    try:
        response = _client.chat.completions.create(
            model    = DEPLOYMENT_NAME,
            messages = [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": user_prompt}
            ],
            max_completion_tokens = 500,
        )

        raw = response.choices[0].message.content.strip()

        if not raw:
            return []

        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        # Parse JSON
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            start = raw.find("[")
            end   = raw.rfind("]") + 1
            if start != -1 and end > start:
                parsed = json.loads(raw[start:end])
            else:
                return []

        # Normalise wrapped responses
        if isinstance(parsed, dict):
            parsed = (
                parsed.get("supporting_members")
                or parsed.get("supporting_member")
                or parsed.get("members")
                or []
            )

        if not isinstance(parsed, list):
            return []

        # Extract member name strings
        members = []
        for item in parsed:
            if isinstance(item, dict):
                name = (
                    item.get("supporting_member")
                    or item.get("name")
                    or ""
                ).strip()
            elif isinstance(item, str):
                name = item.strip()
            else:
                continue
            if name:
                members.append(name)

        return members

    except Exception as e:
        raise RuntimeError(f"Extraction failed: {e}")