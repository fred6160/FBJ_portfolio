# ============================================================
# config.py — Credentials & Settings
# ============================================================

import os

# ── Azure OpenAI ─────────────────────────────────────────
AZURE_ENDPOINT      = os.getenv("AZURE_ENDPOINT",      "https://z-aifoundry-tsbfoundry-prod-swc.cognitiveservices.azure.com/openai/deployments/gpt-5.4-nano/chat/completions?api-version=2025-01-01-preview")
AZURE_TENANT_ID     = os.getenv("AZURE_TENANT_ID",     "23e464d7-04e6-4b87-913c-24bd89219fd3")
AZURE_CLIENT_ID     = os.getenv("AZURE_CLIENT_ID",     "3be057d9-165d-4fbb-9096-1573e9c64db6")
AZURE_CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET", "EK58Q~YRCi52tZBvWeO1HLyB-H~6wJKP5JTkRcuE")
DEPLOYMENT_NAME     = os.getenv("DEPLOYMENT_NAME",      "gpt-5.4-nano")
API_VERSION         = os.getenv("API_VERSION",          "2025-01-01-preview")

# ── ITAD API ──────────────────────────────────────────────
ITAD_API_KEY        = os.getenv("ITAD_API_KEY",         "t97TQdTD1vcpPPog2yWgEkwjJhKytOJKSIg8PZrfbbvdTHFF")
ITAD_SEARCH_URL     = "https://www.itu.int/itad/tsb-ai/api/v1/milvus/search-orgs"
DISTANCE_THRESHOLD  = float(os.getenv("DISTANCE_THRESHOLD", "0.96"))

# ── Processing ────────────────────────────────────────────
MAX_TEXT_LENGTH     = int(os.getenv("MAX_TEXT_LENGTH",  "4000"))
ITAD_TIMEOUT        = int(os.getenv("ITAD_TIMEOUT",     "10"))

# ── CSV lookup path (for document ID input mode) ──────────
EXTRACTED_ORGS_CSV  = os.getenv("EXTRACTED_ORGS_CSV",  "extracted_orgs.csv")