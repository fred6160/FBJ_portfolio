# ============================================================
# main.py — FastAPI Application (v2.0.0)
# ============================================================

import io
import pandas as pd
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from models import MemberResult, HealthResponse
from pipeline import run_pipeline, run_pipeline_on_csv

app = FastAPI(
    title="ITU Member Organisation ID Extraction API",
    description=(
        "Receives ITU document text (plain text or uploaded file), "
        "converts it into a list of supporting member names using AI, "
        "matches each name against the ITAD organisation database, "
        "and returns structured results with org_ids."
    ),
    version="2.0.0",
    contact={
        "name": "ITU-T SG02 — ITAD Intelligence System",
        "email": "tsb@itu.int"
    }
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class TextInput(BaseModel):
    text: str = Field(
        ...,
        description="Raw document text to extract supporting members from.",
        example="Supporting members committing to the work item: Egypt, Sudan and UAE."
    )


# ── CSV reading helper ────────────────────────────────────
def _read_csv_with_fallback(contents: bytes) -> pd.DataFrame:
    """
    Try common encodings in order to read CSV bytes into a DataFrame.
    Raises HTTPException if all encodings fail.
    """
    for encoding in ["utf-8-sig", "utf-8", "latin-1", "cp1252"]:
        try:
            return pd.read_csv(io.StringIO(contents.decode(encoding)))
        except (UnicodeDecodeError, Exception):
            continue
    raise HTTPException(
        status_code=400,
        detail="Could not decode the file. Please save it as UTF-8 and try again."
    )


def _is_fake_xls(contents: bytes) -> bool:
    """
    Returns True if a .xls file is actually CSV content in disguise.
    Real .xls binary files start with the OLE2 signature: 0xD0 0xCF.
    """
    sample = contents[:16]
    return not sample.startswith(b'\xd0\xcf')


# ════════════════════════════════════════════════════════════
# ENDPOINTS
# ════════════════════════════════════════════════════════════

@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["System"],
    summary="Health Check"
)
def health_check():
    """Confirm the API is running and reachable."""
    return HealthResponse(
        status="ok",
        version="2.0.0",
        message="ITU Member Extraction API is running."
    )


@app.post(
    "/extract/text",
    response_model=list[MemberResult],
    tags=["Extraction"],
    summary="Extract Supporting Members from Text"
)
def extract_from_text(payload: TextInput):
    """
    Receives already-extracted document text, converts it into
    a list of supporting member names using AI, matches each
    against the ITAD organisation database, and returns
    a flat list of results with org_ids.

    **Input:**
    - `text` — raw document text string

    **Output:**
    - Flat list of members, each with:
      - `supporting_member` — extracted member name
      - `org_id` — matched organisation ID (null if unmatched)
      - `matched_org_name` — canonical name from ITAD database
      - `match_distance` — cosine similarity score (0–1)
      - `match_status` — matched / below_threshold / no_results / error
    """
    if not payload.text.strip():
        raise HTTPException(
            status_code=400,
            detail="Input text cannot be empty."
        )

    try:
        results = run_pipeline(payload.text)
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pipeline error: {e}")

    return results


@app.post(
    "/extract/csv",
    tags=["Extraction"],
    summary="Extract Supporting Members from File (CSV, Excel, or DOCX)"
)
async def extract_from_csv(
    file: UploadFile = File(
        ...,
        description="CSV (.csv), Excel (.xlsx / .xls), or Word (.docx) file."
    ),
    text_column: str = Form(
        ...,
        description=(
            "Name of the column containing the text to process. "
            "Not required for .docx files."
        )
    ),
):
    """
    Receives a file and the name of the column containing document
    text. Processes every row — extracts supporting member names
    using AI, matches each against the ITAD organisation database,
    and returns all results as a structured JSON response.

    **Supported file types:** .csv, .xlsx, .xls, .docx

    **Input:**
    - `file` — file upload
    - `text_column` — column name containing the text (ignored for .docx)

    **Output:**
    - Summary counts and flat list of all members found across all rows,
      each tagged with row_index and source_text preview.
    """
    contents = await file.read()
    filename  = file.filename.lower()

    # ── Load file into DataFrame based on type ────────────
    try:
        if filename.endswith(".csv"):
            df = _read_csv_with_fallback(contents)

        elif filename.endswith(".xlsx"):
            # Modern Excel format — openpyxl engine
            df = pd.read_excel(io.BytesIO(contents), engine="openpyxl")

        elif filename.endswith(".xls"):
            if _is_fake_xls(contents):
                # File is CSV content saved with a .xls extension — read as CSV
                df = _read_csv_with_fallback(contents)
            else:
                # True legacy Excel binary format — xlrd engine
                df = pd.read_excel(io.BytesIO(contents), engine="xlrd")

        elif filename.endswith(".docx"):
            from docx import Document as DocxDocument
            doc = DocxDocument(io.BytesIO(contents))

            # Collect text from paragraphs
            texts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

            # Also collect text from all table cells
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        cell_text = cell.text.strip()
                        if cell_text and cell_text not in texts:
                            texts.append(cell_text)

            if not texts:
                raise HTTPException(
                    status_code=400,
                    detail="No readable text found in the uploaded Word document."
                )

            df          = pd.DataFrame({"text": texts})
            text_column = "text"   # override — docx has no column name

        else:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Unsupported file type. "
                    "Please upload a .csv, .xlsx, .xls, or .docx file."
                )
            )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not read file: {e}")

    # ── Validate column exists ────────────────────────────
    if text_column not in df.columns:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Column '{text_column}' not found. "
                f"Available columns: {list(df.columns)}"
            )
        )

    if df.empty:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file contains no rows."
        )

    # ── Run pipeline across all rows ──────────────────────
    try:
        results = run_pipeline_on_csv(df, text_column)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pipeline error: {e}")

    # ── Return structured response ────────────────────────
    return {
        "file":           file.filename,
        "text_column":    text_column,
        "rows_processed": len(df),
        "total_members":  len(results),
        "matched":        sum(1 for r in results if r["org_id"]),
        "unmatched":      sum(1 for r in results if not r["org_id"]),
        "results":        results,
    }