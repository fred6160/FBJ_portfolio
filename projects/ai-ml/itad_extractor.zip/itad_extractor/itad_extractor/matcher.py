# ============================================================
# matcher.py — ITAD Organisation ID Matching
# ============================================================

import requests
from config import ITAD_API_KEY, ITAD_SEARCH_URL, DISTANCE_THRESHOLD, ITAD_TIMEOUT
from models import MemberResult


def _query_itad(member_name: str) -> dict:
    """Call the ITAD vector search API for a single member name."""
    response = requests.get(
        ITAD_SEARCH_URL,
        params  = {"query": member_name},
        headers = {"x-api-key": ITAD_API_KEY},
        timeout = ITAD_TIMEOUT
    )
    response.raise_for_status()
    return response.json()


def match_member(member_name: str) -> MemberResult:
    """
    Look up a single member name via ITAD API and apply
    the distance threshold matching rule.
    """
    try:
        data    = _query_itad(member_name)
        results = data.get("data", {}).get("results", [])

        if not results:
            return MemberResult(
                supporting_member = member_name,
                org_id            = None,
                matched_org_name  = None,
                match_distance    = None,
                match_status      = "no_results"
            )

        top      = results[0]
        distance = top.get("distance", 0)

        if distance > DISTANCE_THRESHOLD:
            return MemberResult(
                supporting_member = member_name,
                org_id            = top.get("org_id"),
                matched_org_name  = top.get("org_name"),
                match_distance    = round(distance, 6),
                match_status      = "matched"
            )
        else:
            return MemberResult(
                supporting_member = member_name,
                org_id            = None,
                matched_org_name  = None,
                match_distance    = round(distance, 6),
                match_status      = "below_threshold"
            )

    except requests.exceptions.Timeout:
        return MemberResult(
            supporting_member = member_name,
            org_id            = None,
            matched_org_name  = None,
            match_distance    = None,
            match_status      = "timeout"
        )
    except Exception as e:
        return MemberResult(
            supporting_member = member_name,
            org_id            = None,
            matched_org_name  = None,
            match_distance    = None,
            match_status      = f"error: {str(e)}"
        )


def match_members(member_names: list[str]) -> list[MemberResult]:
    """
    Match a list of member names via ITAD API.
    Each name is queried individually.
    """
    return [match_member(name) for name in member_names]