# ============================================================
# pipeline.py — Pipeline Functions
# ============================================================

import pandas as pd
from extractor import extract_members_from_text
from matcher import match_members
from models import MemberResult


def run_pipeline(text: str) -> list[MemberResult]:
    """
    Full pipeline for a single block of text:
      1. Extract member names via Azure OpenAI
      2. Match each name via ITAD API
      3. Return list of MemberResult
    """
    member_names = extract_members_from_text(text)

    if not member_names:
        return []

    return match_members(member_names)   # ← return directly, no conversion needed


def run_pipeline_on_csv(df: pd.DataFrame, text_column: str) -> list[dict]:
    """
    Full pipeline across every row of a DataFrame.
    """
    all_results = []

    for row_idx, row in df.iterrows():
        text = str(row[text_column]).strip()

        if not text or text.lower() == "nan":
            continue

        results = run_pipeline(text)

        for r in results:
            all_results.append({
                "row_index":        int(row_idx),
                "source_text":      text[:120],
                "supporting_member": r.supporting_member,
                "org_id":           r.org_id,
                "matched_org_name": r.matched_org_name,
                "match_distance":   r.match_distance,
                "match_status":     r.match_status,
            })

    return all_results