# ============================================================
# models.py — Request & Response Schemas
# ============================================================

from pydantic import BaseModel, Field
from typing import Optional


class MemberResult(BaseModel):
    """Single member result returned by both endpoints."""
    supporting_member: str
    org_id:            Optional[str]
    matched_org_name:  Optional[str]
    match_distance:    Optional[float]
    match_status:      str


class HealthResponse(BaseModel):
    status:  str
    version: str
    message: str